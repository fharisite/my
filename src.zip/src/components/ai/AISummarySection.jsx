import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, RefreshCw, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const PROMPTS = {
  author: (entity) => `
أنت ناقد أدبي وأكاديمي متخصص. اكتب تحليلاً أدبياً شاملاً ومعمّقاً عن المؤلف التالي:

الاسم: ${entity.name}
الجنسية: ${entity.nationality || 'غير محددة'}
سنة الميلاد: ${entity.birth_year || 'غير محددة'}
${entity.death_year ? `سنة الوفاة: ${entity.death_year}` : ''}
النبذة المتاحة: ${entity.bio || 'لا توجد'}
التعليم: ${entity.education || 'غير محدد'}
الجوائز: ${entity.awards?.join('، ') || 'غير محددة'}

اكتب تحليلاً أدبياً متكاملاً يشمل بشكل صريح ومفصّل:

**الأسلوب الأدبي:**
صف بدقة أسلوب الكاتب في الكتابة: طريقة بناء الجمل، نوع اللغة (بسيطة/معقدة/شاعرية)، أسلوب السرد، استخدام الرمز والاستعارة، وما يميزه عن غيره.

**السياق التاريخي والثقافي:**
اشرح الحقبة الزمنية والبيئة الثقافية التي نشأ وكتب فيها المؤلف، وكيف أثّر ذلك على إنتاجه الأدبي ورؤيته للعالم.

**أبرز التأثيرات والمؤثرات:**
من أثّر في هذا المؤلف من كتّاب أو مدارس أدبية أو أحداث تاريخية؟ ومن تأثّر به من الأجيال اللاحقة؟

**المواضيع المتكررة والإسهامات:**
ما القضايا والموضوعات التي يعود إليها المؤلف باستمرار؟ وما أبرز مساهماته في الأدب أو الفكر؟

اكتب بأسلوب أكاديمي رصين ومشوق باللغة العربية، في 4-5 فقرات متماسكة (250-300 كلمة).
`,
  publisher: (entity) => `
أنت محلل في صناعة النشر. اكتب ملخصاً شاملاً ومثرياً عن دار النشر التالية:

الاسم: ${entity.name}
الدولة: ${entity.country || 'غير محددة'}
سنة التأسيس: ${entity.founded_year || 'غير محددة'}
الوصف المتاح: ${entity.description || 'لا يوجد'}
التخصصات: ${entity.specialization?.join('، ') || 'غير محددة'}

اكتب ملخصاً متكاملاً يشمل:
1. تاريخ دار النشر ونشأتها ورحلتها في عالم الكتاب
2. أثرها وإسهامها في المشهد الأدبي والثقافي
3. تخصصاتها الرئيسية وما تتميز به من رؤية نشرية
4. دورها في دعم الكتّاب وإيصال الأفكار للقراء
5. مكانتها الراهنة في صناعة النشر

اكتب بأسلوب احترافي مشوق باللغة العربية، في فقرة واحدة متماسكة من 150-200 كلمة.
`,
};

export default function AISummarySection({ entity, entityType, onSummaryGenerated, isAdmin }) {
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const prompt = PROMPTS[entityType](entity);
      const summary = await base44.integrations.Core.InvokeLLM({ prompt });

      // Save to entity
      if (entityType === 'author') {
        await base44.entities.Author.update(entity.id, { ai_summary: summary });
      } else {
        await base44.entities.Publisher.update(entity.id, { ai_summary: summary });
      }

      onSummaryGenerated(summary);
      toast.success('تم إنشاء الملخص بنجاح');
    } catch (err) {
      toast.error('فشل إنشاء الملخص: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const hasSummary = !!entity.ai_summary;

  return (
    <div className="mt-8 sm:mt-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-purple-600" />
          {hasSummary ? 'الملخص الذكي' : 'توليد ملخص ذكي'}
        </h2>
        {isAdmin && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleGenerate}
            disabled={loading}
            className="gap-2 border-purple-300 text-purple-700 hover:bg-purple-50"
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> جاري التوليد...</>
            ) : hasSummary ? (
              <><RefreshCw className="w-4 h-4" /> إعادة توليد</>
            ) : (
              <><Sparkles className="w-4 h-4" /> توليد بالذكاء الاصطناعي</>
            )}
          </Button>
        )}
      </div>

      {hasSummary ? (
        <Card className="border-purple-200 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="bg-gradient-to-r from-purple-600 to-indigo-600 px-5 py-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-white" />
              <span className="text-white text-sm font-medium">تحليل بالذكاء الاصطناعي</span>
            </div>
            <div className="p-6" style={{ background: 'linear-gradient(to bottom right, #faf5ff, #f3e8ff)' }}>
              {entity.ai_summary.split('\n').filter(p => p.trim()).map((para, i) => {
                const isBold = para.startsWith('**') && para.includes('**');
                if (isBold) {
                  const label = para.replace(/\*\*/g, '').replace(':', '').trim();
                  return (
                    <h4 key={i} className="font-bold text-purple-800 mt-4 mb-1 first:mt-0 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-500 inline-block" />
                      {label}
                    </h4>
                  );
                }
                return <p key={i} className="text-gray-700 leading-loose text-base mb-2">{para}</p>;
              })}
            </div>
          </CardContent>
        </Card>
      ) : !isAdmin ? null : (
        <Card className="border-dashed border-2 border-purple-200 bg-purple-50/30">
          <CardContent className="py-10 text-center">
            <Sparkles className="w-10 h-10 text-purple-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm mb-4">
              لا يوجد ملخص ذكي بعد. اضغط على الزر أعلاه لتوليد ملخص شامل.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}