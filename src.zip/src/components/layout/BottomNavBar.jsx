import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Home, BookOpen, Users, UserCircle } from 'lucide-react';

export default function BottomNavBar() {
  const location = useLocation();
  
  const isActive = (path) => {
    return location.pathname === `/${path}` || location.pathname === `/pages/${path}`;
  };

  const navItems = [
    { name: 'الرئيسية', path: 'Home', icon: Home },
    { name: 'الكتب', path: 'Books', icon: BookOpen },
    { name: 'المؤلفون', path: 'Authors', icon: Users },
    { name: 'حسابي', path: 'MyProfile', icon: UserCircle },
  ];

  return (
    <nav 
      className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 z-50 shadow-lg"
      style={{
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <div className="grid grid-cols-4 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          
          return (
            <Link
              key={item.path}
              to={createPageUrl(item.path)}
              className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                active 
                  ? 'text-orange-600 dark:text-orange-400' 
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              <Icon className={`w-6 h-6 ${active ? 'fill-orange-100 dark:fill-orange-900' : ''}`} />
              <span className="text-xs font-medium">{item.name}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}