import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Star, BookOpen } from 'lucide-react';

export default function SimilarBooks({ book }) {
  const { data: allBooks = [] } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
    staleTime: 5 * 60 * 1000,
  });

  const similar = allBooks
    .filter(b => b.id !== book.id)
    .map(b => {
      let score = 0;
      // Same author
      if (book.author_id && b.author_id === book.author_id) score += 4;
      if (book.author && b.author === book.author) score += 2;
      // Same publisher
      if (book.publisher_id && b.publisher_id === book.publisher_id) score += 2;
      // Matching genres
      if (book.genres?.length && b.genres?.length) {
        const shared = book.genres.filter(g => b.genres.includes(g));
        score += shared.length * 2;
      }
      // Same category
      if (book.category && b.category === book.category) score += 3;
      // Matching tags
      if (book.tags?.length && b.tags?.length) {
        const shared = book.tags.filter(t => b.tags.includes(t));
        score += shared.length;
      }
      // Same language
      if (book.language && b.language === book.language) score += 1;
      return { ...b, score };
    })
    .filter(b => b.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8);

  if (similar.length === 0) return null;

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <BookOpen className="w-6 h-6" style={{ color: '#75420e' }} />
        <h2 className="text-2xl font-bold text-gray-900">كتب مشابهة</h2>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {similar.map(b => (
          <Link key={b.id} to={createPageUrl(`BookDetail?id=${b.id}`)}>
            <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer h-full">
              <CardContent className="p-0">
                <img
                  src={b.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                  alt={b.title}
                  className="w-full aspect-[2/3] object-cover rounded-t-xl"
                />
                <div className="p-3">
                  <h3 className="font-semibold text-sm text-gray-900 line-clamp-2 mb-1">{b.title}</h3>
                  <p className="text-xs text-gray-500">{b.author}</p>
                  {b.average_rating > 0 && (
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs font-medium text-gray-700">{b.average_rating?.toFixed(1)}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}