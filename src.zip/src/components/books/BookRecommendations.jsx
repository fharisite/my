import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Star, Sparkles } from 'lucide-react';

export default function BookRecommendations() {
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: recommendationsData, isLoading } = useQuery({
    queryKey: ['bookRecommendations', user?.email],
    queryFn: async () => {
      const response = await base44.functions.invoke('getBookRecommendations', {});
      return response.data;
    },
    enabled: !!user,
  });

  if (!user || !recommendationsData?.recommendations || recommendationsData.recommendations.length === 0) {
    return null;
  }

  return (
    <section className="mb-12">
      <div className="flex items-center gap-3 mb-6">
        <Sparkles className="w-6 h-6 text-orange-600" />
        <h2 className="text-2xl font-bold text-gray-900">مقترحة لك</h2>
      </div>
      
      {recommendationsData.reason && (
        <p className="text-gray-600 mb-4 text-sm">{recommendationsData.reason}</p>
      )}

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="w-full aspect-[2/3] bg-gray-200 rounded-lg mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {recommendationsData.recommendations.map((book) => (
            <Link key={book.id} to={createPageUrl(`BookDetail?id=${book.id}`)}>
              <Card className="hover:shadow-xl transition-all hover:scale-105 cursor-pointer h-full relative overflow-hidden">
                <div className="absolute top-2 right-2 z-10 bg-orange-500 text-white px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  مقترح
                </div>
                <CardContent className="p-0">
                  <img
                    src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                    alt={book.title}
                    className="w-full aspect-[2/3] object-cover rounded-t-lg"
                  />
                  <div className="p-3">
                    <h3 className="font-semibold text-sm text-gray-900 mb-1 line-clamp-2">
                      {book.title}
                    </h3>
                    <p className="text-xs text-gray-600 mb-2">{book.author_name}</p>
                    {book.rating && (
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                        <span className="text-xs font-semibold">{book.rating}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}