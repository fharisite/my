import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Star } from 'lucide-react';

export default function BookReviewDialog({ open, onOpenChange, item, onSave }) {
  const [rating, setRating] = useState(item?.personal_rating || 0);
  const [review, setReview] = useState(item?.review || '');
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleSave = () => {
    onSave({
      personal_rating: rating,
      review: review
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir="rtl" className="max-w-lg">
        <DialogHeader>
          <DialogTitle>تقييم ومراجعة الكتاب</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>تقييمك الشخصي</Label>
            <div className="flex gap-2 mt-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-500 text-yellow-500'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label htmlFor="review">مراجعتك</Label>
            <Textarea
              id="review"
              value={review}
              onChange={(e) => setReview(e.target.value)}
              rows={5}
              placeholder="اكتب مراجعتك الشخصية للكتاب..."
              className="text-right mt-2"
            />
          </div>
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button onClick={handleSave} className="bg-gradient-to-l from-orange-600 to-amber-600">
              حفظ
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}