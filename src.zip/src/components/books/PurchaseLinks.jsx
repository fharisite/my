import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, ExternalLink } from 'lucide-react';

export default function PurchaseLinks({ purchaseLinks }) {
  if (!purchaseLinks || purchaseLinks.length === 0) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-green-900 mb-4 flex items-center gap-2">
          <ShoppingCart className="w-5 h-5" />
          اشتر الكتاب
        </h3>
        <div className="space-y-3">
          {purchaseLinks.map((link, index) => (
            <a
              key={index}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button
                variant="outline"
                className="w-full justify-between hover:bg-green-100 hover:border-green-400"
              >
                <div className="flex items-center gap-3">
                  <ShoppingCart className="w-4 h-4" />
                  <div className="text-right">
                    <div className="font-semibold">{link.store}</div>
                    {link.price && (
                      <div className="text-sm text-gray-600">{link.price}</div>
                    )}
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </Button>
            </a>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}