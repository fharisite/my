import React from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Search, X } from 'lucide-react';

export default function AdvancedSearch({ filters, onFiltersChange, onClear }) {
  const categories = [
    'روايات وقصص',
    'كتب الأدب',
    'كتب تاريخية',
    'كتب دينية',
    'كتب سياسية',
    'كتب علمية',
    'مال وأعمال',
    'علم النفس وتطوير الذات',
    'السيرة الذاتية والمذكرات'
  ];

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 50 }, (_, i) => currentYear - i);

  return (
    <Card className="bg-white shadow-lg">
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <Search className="w-5 h-5 text-orange-600" />
            البحث المتقدم
          </h3>
          <Button variant="ghost" size="sm" onClick={onClear}>
            <X className="w-4 h-4 ml-1" />
            مسح الفلاتر
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {/* Search by Title */}
          <div>
            <Label className="text-sm font-medium text-gray-700">العنوان</Label>
            <Input
              placeholder="ابحث عن عنوان الكتاب..."
              value={filters.title}
              onChange={(e) => onFiltersChange({ ...filters, title: e.target.value })}
              className="mt-1"
            />
          </div>

          {/* Search by Author */}
          <div>
            <Label className="text-sm font-medium text-gray-700">المؤلف</Label>
            <Input
              placeholder="ابحث عن اسم المؤلف..."
              value={filters.author}
              onChange={(e) => onFiltersChange({ ...filters, author: e.target.value })}
              className="mt-1"
            />
          </div>

          {/* Search by ISBN */}
          <div>
            <Label className="text-sm font-medium text-gray-700">ISBN</Label>
            <Input
              placeholder="أدخل رقم ISBN..."
              value={filters.isbn}
              onChange={(e) => onFiltersChange({ ...filters, isbn: e.target.value })}
              className="mt-1"
            />
          </div>

          {/* Search by Publisher */}
          <div>
            <Label className="text-sm font-medium text-gray-700">الناشر</Label>
            <Input
              placeholder="ابحث عن دار النشر..."
              value={filters.publisher}
              onChange={(e) => onFiltersChange({ ...filters, publisher: e.target.value })}
              className="mt-1"
            />
          </div>

          {/* Search by Tags */}
          <div>
            <Label className="text-sm font-medium text-gray-700">الوسوم</Label>
            <Input
              placeholder="ابحث في الوسوم..."
              value={filters.tags}
              onChange={(e) => onFiltersChange({ ...filters, tags: e.target.value })}
              className="mt-1"
            />
          </div>

          {/* Category Filter */}
          <div>
            <Label className="text-sm font-medium text-gray-700">التصنيف</Label>
            <Select 
              value={filters.category} 
              onValueChange={(value) => onFiltersChange({ ...filters, category: value })}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="جميع التصنيفات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع التصنيفات</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Publication Year */}
          <div>
            <Label className="text-sm font-medium text-gray-700">سنة النشر</Label>
            <Select 
              value={filters.year} 
              onValueChange={(value) => onFiltersChange({ ...filters, year: value })}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="جميع السنوات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع السنوات</SelectItem>
                <SelectItem value="recent">آخر 5 سنوات</SelectItem>
                <SelectItem value="2020s">عقد 2020</SelectItem>
                <SelectItem value="2010s">عقد 2010</SelectItem>
                <SelectItem value="2000s">عقد 2000</SelectItem>
                <SelectItem value="classic">كلاسيكية (قبل 2000)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Rating Filter */}
          <div>
            <Label className="text-sm font-medium text-gray-700">التقييم الأدنى</Label>
            <Select 
              value={filters.minRating} 
              onValueChange={(value) => onFiltersChange({ ...filters, minRating: value })}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="جميع التقييمات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع التقييمات</SelectItem>
                <SelectItem value="4.5">4.5 ★ وأعلى</SelectItem>
                <SelectItem value="4.0">4.0 ★ وأعلى</SelectItem>
                <SelectItem value="3.5">3.5 ★ وأعلى</SelectItem>
                <SelectItem value="3.0">3.0 ★ وأعلى</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Audio Books */}
          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="audioOnly"
              checked={filters.audioOnly}
              onChange={(e) => onFiltersChange({ ...filters, audioOnly: e.target.checked })}
              className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500"
            />
            <Label htmlFor="audioOnly" className="text-sm font-medium text-gray-700 cursor-pointer">
              الكتب الصوتية فقط 🎧
            </Label>
          </div>

          {/* Featured Books */}
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="featuredOnly"
              checked={filters.featuredOnly}
              onChange={(e) => onFiltersChange({ ...filters, featuredOnly: e.target.checked })}
              className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500"
            />
            <Label htmlFor="featuredOnly" className="text-sm font-medium text-gray-700 cursor-pointer">
              الكتب المميزة فقط ⭐
            </Label>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}