import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Star, MessageSquarePlus } from 'lucide-react';
import { toast } from 'sonner';

export default function BookReviews({ bookId }) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [showForm, setShowForm] = useState(false);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews', bookId],
    queryFn: () => base44.entities.BookReview.filter({ book_id: bookId }, '-created_date'),
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.BookReview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews', bookId] });
      queryClient.invalidateQueries({ queryKey: ['books'] });
      setRating(0);
      setReviewText('');
      setShowForm(false);
      toast.success('تم إضافة تقييمك بنجاح');
    },
  });

  const handleSubmit = () => {
    if (!user) {
      toast.error('يجب تسجيل الدخول أولاً');
      return;
    }
    if (rating === 0) {
      toast.error('الرجاء اختيار تقييم');
      return;
    }

    createReviewMutation.mutate({
      book_id: bookId,
      user_email: user.email,
      rating: rating,
      review_text: reviewText,
    });
  };

  const userReview = reviews.find(r => r.user_email === user?.email);
  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : 0;

  // Rating distribution
  const ratingCounts = [5, 4, 3, 2, 1].map(star => ({
    star,
    count: reviews.filter(r => r.rating === star).length,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-2">
        <Star className="w-6 h-6 text-yellow-500 fill-yellow-400" />
        <h2 className="text-2xl font-bold text-gray-900">التقييمات والآراء</h2>
      </div>

      {/* Summary Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-6 items-center sm:items-start">
            {/* Average */}
            <div className="text-center flex-shrink-0">
              <div className="text-6xl font-bold text-gray-900">{averageRating}</div>
              <div className="flex items-center justify-center gap-0.5 mt-2">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star key={star} className={`w-5 h-5 ${star <= Math.round(averageRating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
                ))}
              </div>
              <p className="text-sm text-gray-500 mt-1">{reviews.length} تقييم</p>
            </div>

            {/* Distribution bars */}
            <div className="flex-1 w-full space-y-1.5">
              {ratingCounts.map(({ star, count }) => {
                const pct = reviews.length ? Math.round((count / reviews.length) * 100) : 0;
                return (
                  <div key={star} className="flex items-center gap-2 text-sm">
                    <span className="w-3 text-gray-600 font-medium">{star}</span>
                    <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400 flex-shrink-0" />
                    <div className="flex-1 bg-gray-100 rounded-full h-2.5 overflow-hidden">
                      <div className="h-full rounded-full bg-yellow-400 transition-all" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-8 text-left text-gray-500 text-xs">{count}</span>
                  </div>
                );
              })}
            </div>

            {/* Add review button */}
            {!userReview && !showForm && (
              <Button
                onClick={() => setShowForm(true)}
                className="text-white flex-shrink-0 gap-2"
                style={{ background: 'linear-gradient(to left, #75420e, #553b08)' }}
              >
                <MessageSquarePlus className="w-4 h-4" />
                أضف تقييمك
              </Button>
            )}
          </div>

          {/* Add Review Form */}
          {!userReview && showForm && (
            <div className="mt-6 pt-6 border-t space-y-4">
              <h4 className="font-semibold text-gray-900">أضف تقييمك</h4>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map(star => (
                  <button key={star} onMouseEnter={() => setHoveredRating(star)} onMouseLeave={() => setHoveredRating(0)} onClick={() => setRating(star)}>
                    <Star className={`w-9 h-9 cursor-pointer transition-all ${star <= (hoveredRating || rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
                  </button>
                ))}
                {rating > 0 && <span className="self-center text-sm text-gray-600 mr-1">{['', 'ضعيف', 'مقبول', 'جيد', 'رائع', 'ممتاز'][rating]}</span>}
              </div>
              <Textarea placeholder="شاركنا رأيك في الكتاب..." value={reviewText} onChange={e => setReviewText(e.target.value)} rows={3} />
              <div className="flex gap-2">
                <Button onClick={handleSubmit} disabled={createReviewMutation.isPending} className="text-white" style={{ background: 'linear-gradient(to left, #75420e, #553b08)' }}>
                  إرسال التقييم
                </Button>
                <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
              </div>
            </div>
          )}

          {userReview && (
            <div className="mt-4 pt-4 border-t flex items-center gap-2 text-sm text-green-700 bg-green-50 rounded-lg p-3">
              <Star className="w-4 h-4 fill-green-500 text-green-500" />
              لقد قيّمت هذا الكتاب بـ {userReview.rating} نجوم
            </div>
          )}
        </CardContent>
      </Card>

      {/* Reviews List */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-800">آراء القراء</h3>
        {reviews.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-gray-400">
              لا توجد تقييمات حتى الآن. كن أول من يقيم هذا الكتاب!
            </CardContent>
          </Card>
        ) : (
          reviews.map(review => (
            <Card key={review.id} className={review.user_email === userReview?.user_email ? 'ring-2 ring-amber-200' : ''}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0" style={{ background: 'linear-gradient(to br, #75420e, #a05a20)' }}>
                      {review.user_email?.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{review.user_email?.split('@')[0]}</p>
                      <div className="flex gap-0.5 mt-0.5">
                        {[1, 2, 3, 4, 5].map(star => (
                          <Star key={star} className={`w-3.5 h-3.5 ${star <= review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400">{new Date(review.created_date).toLocaleDateString('ar-SA')}</span>
                </div>
                {review.review_text && (
                  <p className="text-gray-700 text-sm leading-relaxed mr-12">{review.review_text}</p>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}