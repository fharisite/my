import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Send } from 'lucide-react';
import { toast } from 'sonner';

export default function BookDiscussions({ bookId }) {
  const [newComment, setNewComment] = useState('');
  const [replyTo, setReplyTo] = useState(null);
  const [replyText, setReplyText] = useState('');

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: discussions = [] } = useQuery({
    queryKey: ['discussions', bookId],
    queryFn: () => base44.entities.BookDiscussion.filter({ book_id: bookId }, '-created_date'),
  });

  const createDiscussionMutation = useMutation({
    mutationFn: (data) => base44.entities.BookDiscussion.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discussions', bookId] });
      setNewComment('');
      setReplyTo(null);
      setReplyText('');
      toast.success('تم إضافة تعليقك بنجاح');
    },
  });

  const handleSubmit = () => {
    if (!user) {
      toast.error('يجب تسجيل الدخول أولاً');
      return;
    }
    if (!newComment.trim()) {
      toast.error('الرجاء كتابة تعليق');
      return;
    }

    createDiscussionMutation.mutate({
      book_id: bookId,
      user_email: user.email,
      user_name: user.full_name || user.email,
      content: newComment,
    });
  };

  const handleReply = (parentId) => {
    if (!user) {
      toast.error('يجب تسجيل الدخول أولاً');
      return;
    }
    if (!replyText.trim()) {
      toast.error('الرجاء كتابة رد');
      return;
    }

    createDiscussionMutation.mutate({
      book_id: bookId,
      user_email: user.email,
      user_name: user.full_name || user.email,
      content: replyText,
      parent_id: parentId,
    });
  };

  const mainComments = discussions.filter(d => !d.parent_id);
  const getReplies = (commentId) => discussions.filter(d => d.parent_id === commentId);

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-bold flex items-center gap-2">
        <MessageCircle className="w-6 h-6" />
        النقاشات ({discussions.length})
      </h3>

      {/* New Comment Form */}
      <Card>
        <CardContent className="p-4">
          <Textarea
            placeholder="شارك رأيك أو ابدأ نقاشاً حول هذا الكتاب..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            rows={3}
          />
          <div className="flex justify-end mt-3">
            <Button
              onClick={handleSubmit}
              disabled={createDiscussionMutation.isPending}
              className="bg-gradient-to-l from-orange-600 to-amber-600"
            >
              <Send className="w-4 h-4 ml-2" />
              نشر التعليق
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Comments List */}
      <div className="space-y-4">
        {mainComments.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-gray-500">
              لا توجد نقاشات حتى الآن. كن أول من يبدأ النقاش!
            </CardContent>
          </Card>
        ) : (
          mainComments.map((comment) => {
            const replies = getReplies(comment.id);
            return (
              <Card key={comment.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="font-semibold text-gray-900">
                        {comment.user_name || comment.user_email}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(comment.created_date).toLocaleDateString('ar-SA')}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed mb-3">{comment.content}</p>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                  >
                    <MessageCircle className="w-4 h-4 ml-2" />
                    رد ({replies.length})
                  </Button>

                  {/* Reply Form */}
                  {replyTo === comment.id && (
                    <div className="mt-4 mr-8 space-y-3">
                      <Textarea
                        placeholder="اكتب ردك..."
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        rows={2}
                      />
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleReply(comment.id)}
                          disabled={createDiscussionMutation.isPending}
                        >
                          إرسال الرد
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setReplyTo(null);
                            setReplyText('');
                          }}
                        >
                          إلغاء
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Replies List */}
                  {replies.length > 0 && (
                    <div className="mt-4 mr-8 space-y-3">
                      {replies.map((reply) => (
                        <div key={reply.id} className="border-r-2 border-orange-200 pr-4">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <div className="font-semibold text-sm text-gray-900">
                                {reply.user_name || reply.user_email}
                              </div>
                              <div className="text-xs text-gray-500">
                                {new Date(reply.created_date).toLocaleDateString('ar-SA')}
                              </div>
                            </div>
                          </div>
                          <p className="text-gray-700 text-sm leading-relaxed">{reply.content}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}