import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Calendar, BookOpen, Globe, UserPlus, UserCheck, Edit, Users, Building2, TrendingUp, Tag, Headphones, Star } from 'lucide-react';
import ModernHeader from '../components/layout/ModernHeader';
import AISummarySection from '../components/ai/AISummarySection';

export default function PublisherDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const publisherId = urlParams.get('id');
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: publishers = [] } = useQuery({
    queryKey: ['publishers'],
    queryFn: () => base44.entities.Publisher.list(),
  });

  const { data: books = [] } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
  });

  const { data: follows = [] } = useQuery({
    queryKey: ['publisherFollows', publisherId],
    queryFn: () => base44.entities.PublisherFollow.filter({ publisher_id: publisherId }),
  });

  const followMutation = useMutation({
    mutationFn: (data) => base44.entities.PublisherFollow.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['publisherFollows', publisherId] });
      toast.success('تمت المتابعة بنجاح');
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: (id) => base44.entities.PublisherFollow.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['publisherFollows', publisherId] });
      toast.success('تم إلغاء المتابعة');
    },
  });

  const [publisherAiSummary, setPublisherAiSummary] = useState(null);
  const publisher = publishers.find(p => p.id === publisherId);
  const publisherWithSummary = publisher ? { ...publisher, ai_summary: publisherAiSummary ?? publisher.ai_summary } : publisher;
  const publisherBooks = books.filter(b => b.publisher_id === publisherId);
  const isFollowing = follows.find(f => f.follower_email === user?.email);

  // Calculate additional stats
  const totalPages = publisherBooks.reduce((sum, book) => sum + (book.pages || 0), 0);
  const avgRating = publisherBooks.length > 0 
    ? (publisherBooks.reduce((sum, book) => sum + (book.rating || 0), 0) / publisherBooks.length).toFixed(1)
    : 0;
  const categories = new Set(publisherBooks.map(b => b.category)).size;
  const audioBooks = publisherBooks.filter(b => b.audio_available).length;
  const yearsInBusiness = publisher.founded_year ? new Date().getFullYear() - publisher.founded_year : 0;

  const handleFollowToggle = () => {
    if (!user) {
      toast.error('يجب تسجيل الدخول أولاً');
      return;
    }
    if (isFollowing) {
      unfollowMutation.mutate(isFollowing.id);
    } else {
      followMutation.mutate({
        publisher_id: publisherId,
        follower_email: user.email,
      });
    }
  };

  if (!publisher) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <p className="text-gray-600 mb-4">دار النشر غير موجودة</p>
          <Link to={createPageUrl('Home')}>
            <Button>العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50" dir="rtl">
      <ModernHeader />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Publisher Info */}
        <Card className="mb-12 shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-l from-blue-600 to-indigo-600 h-32"></div>
          <CardContent className="p-6 sm:p-8 -mt-16">
            <div className="flex flex-col md:flex-row gap-6 md:gap-8">
              {/* Publisher Logo */}
              <div className="flex-shrink-0 mx-auto md:mx-0">
                {publisher.logo ? (
                  <div className="w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 bg-white rounded-2xl shadow-2xl ring-4 ring-white flex items-center justify-center p-4">
                    <img
                      src={publisher.logo}
                      alt={publisher.name}
                      className="w-full h-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-2xl shadow-2xl ring-4 ring-white flex items-center justify-center">
                    <Building2 className="w-20 h-20 text-white" />
                  </div>
                )}
              </div>

              {/* Publisher Details */}
              <div className="flex-1 text-center md:text-right">
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-3">{publisher.name}</h1>
                
                {/* Quick Info */}
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 sm:gap-4 mb-6">
                  {publisher.country && (
                    <div className="flex items-center gap-2 bg-blue-50 px-3 py-1.5 rounded-full">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">{publisher.country}</span>
                    </div>
                  )}
                  {publisher.founded_year && (
                    <div className="flex items-center gap-2 bg-green-50 px-3 py-1.5 rounded-full">
                      <Calendar className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-gray-700">تأسست {publisher.founded_year}</span>
                    </div>
                  )}
                  {publisher.website && (
                    <a 
                      href={publisher.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 bg-orange-50 px-3 py-1.5 rounded-full hover:bg-orange-100 transition-colors"
                    >
                      <Globe className="w-4 h-4 text-orange-600" />
                      <span className="text-sm font-medium text-gray-700">زيارة الموقع</span>
                    </a>
                  )}
                </div>

                {/* Statistics Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <BookOpen className="w-5 h-5 text-blue-600" />
                      <span className="text-xs text-gray-600 font-medium">الكتب</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{publisherBooks.length}</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Users className="w-5 h-5 text-green-600" />
                      <span className="text-xs text-gray-600 font-medium">المتابعون</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{follows.length}</p>
                  </div>
                  <div className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-xl p-4 border border-yellow-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Star className="w-5 h-5 text-yellow-500" />
                      <span className="text-xs text-gray-600 font-medium">التقييم</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{avgRating}</p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Headphones className="w-5 h-5 text-purple-600" />
                      <span className="text-xs text-gray-600 font-medium">صوتي</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{audioBooks}</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                  <Button
                    onClick={handleFollowToggle}
                    size="lg"
                    variant={isFollowing ? "outline" : "default"}
                    className={`${!isFollowing && "bg-gradient-to-l from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"} shadow-lg`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-5 h-5 ml-2" />
                        تمت المتابعة
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-5 h-5 ml-2" />
                        متابعة الناشر
                      </>
                    )}
                  </Button>
                  {user?.role === 'admin' ? (
                    <Link to={createPageUrl(`AuthorsPublishers?editPublisher=${publisherId}`)}>
                      <Button size="lg" className="bg-orange-600 hover:bg-orange-700 shadow-lg">
                        <Edit className="w-5 h-5 ml-2" />
                        تحرير البيانات
                      </Button>
                    </Link>
                  ) : (
                    <Link to={createPageUrl(`SuggestEdit?type=Publisher&id=${publisherId}`)}>
                      <Button variant="outline" size="lg" className="shadow-lg">
                        <Edit className="w-5 h-5 ml-2" />
                        اقترح تعديل
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </div>

            {/* Additional Info Section */}
            <div className="mt-8 sm:mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {yearsInBusiness > 0 && (
                <div className="p-4 rounded-lg border bg-blue-50 border-blue-200">
                  <p className="text-sm text-gray-700 font-medium mb-1">سنوات العمل</p>
                  <p className="text-2xl font-bold text-blue-600">{yearsInBusiness}+ سنة</p>
                </div>
              )}
              {categories > 0 && (
                <div className="p-4 rounded-lg border bg-purple-50 border-purple-200">
                  <div className="flex items-center gap-2 mb-1">
                    <Tag className="w-4 h-4 text-purple-600" />
                    <p className="text-sm text-gray-700 font-medium">التصنيفات</p>
                  </div>
                  <p className="text-2xl font-bold text-purple-600">{categories}</p>
                </div>
              )}
              {totalPages > 0 && (
                <div className="p-4 rounded-lg border bg-orange-50 border-orange-200">
                  <p className="text-sm text-gray-700 font-medium mb-1">إجمالي الصفحات</p>
                  <p className="text-2xl font-bold text-orange-600">{totalPages}</p>
                </div>
              )}
            </div>

            {/* Description Section */}
            {publisher.description && (
              <div className="mt-8 sm:mt-10">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                  نبذة عن دار النشر
                </h2>
                <p className="text-base sm:text-lg text-gray-700 leading-relaxed bg-gradient-to-br from-gray-50 to-blue-50/30 p-6 sm:p-8 rounded-xl border-r-4 border-blue-500">
                  {publisher.description}
                </p>
              </div>
            )}

            <AISummarySection
              entity={publisherWithSummary}
              entityType="publisher"
              isAdmin={user?.role === 'admin'}
              onSummaryGenerated={(s) => setPublisherAiSummary(s)}
            />

            {/* Specialization */}
            {publisher.specialization && publisher.specialization.length > 0 && (
              <div className="mt-8 sm:mt-10">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                      <Tag className="w-5 h-5 text-indigo-600" />
                      التخصصات الرئيسية
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {publisher.specialization.map((spec, idx) => (
                        <span key={idx} className="px-4 py-2 rounded-full bg-indigo-100 text-indigo-700 text-sm font-medium">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Contact Information */}
            {(publisher.email || publisher.phone || publisher.address || publisher.social_media) && (
              <div className="mt-8 sm:mt-10">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">معلومات الاتصال</h2>
                <Card>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {publisher.email && (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <span className="text-lg">📧</span>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-1">البريد الإلكتروني</p>
                            <a href={`mailto:${publisher.email}`} className="text-blue-600 hover:underline font-medium">
                              {publisher.email}
                            </a>
                          </div>
                        </div>
                      )}
                      {publisher.phone && (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">
                          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                            <span className="text-lg">📱</span>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-1">رقم الهاتف</p>
                            <a href={`tel:${publisher.phone}`} className="text-green-600 hover:underline font-medium">
                              {publisher.phone}
                            </a>
                          </div>
                        </div>
                      )}
                      {publisher.address && (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 md:col-span-2">
                          <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-orange-600" />
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-1">العنوان</p>
                            <p className="text-gray-700 font-medium">{publisher.address}</p>
                          </div>
                        </div>
                      )}
                    </div>
                    {publisher.social_media && (
                      <div className="mt-4 pt-4 border-t">
                        <p className="text-sm text-gray-600 mb-3 font-medium">حسابات التواصل الاجتماعي</p>
                        <div className="flex flex-wrap gap-3">
                          {publisher.social_media.twitter && (
                            <a 
                              href={publisher.social_media.twitter} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
                            >
                              <span className="text-lg">𝕏</span>
                              <span className="text-sm font-medium">تويتر</span>
                            </a>
                          )}
                          {publisher.social_media.facebook && (
                            <a 
                              href={publisher.social_media.facebook} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
                            >
                              <span className="text-lg">📘</span>
                              <span className="text-sm font-medium">فيسبوك</span>
                            </a>
                          )}
                          {publisher.social_media.instagram && (
                            <a 
                              href={publisher.social_media.instagram} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-pink-50 hover:bg-pink-100 transition-colors"
                            >
                              <span className="text-lg">📷</span>
                              <span className="text-sm font-medium">انستغرام</span>
                            </a>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Publisher Books */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3">
              <BookOpen className="w-7 h-7 text-blue-600" />
              إصدارات {publisher.name}
            </h2>
            <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full font-bold">
              {publisherBooks.length} كتاب
            </div>
          </div>
          
          {publisherBooks.length === 0 ? (
            <Card className="text-center py-16 sm:py-20 bg-white/50">
              <CardContent>
                <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">لا توجد كتب لهذه الدار حالياً</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-6">
              {publisherBooks.map((book) => (
                <Link key={book.id} to={createPageUrl(`BookDetail?id=${book.id}`)}>
                  <Card className="hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer h-full group">
                    <CardContent className="p-0">
                      <div className="relative overflow-hidden rounded-t-lg">
                        <img
                          src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                          alt={book.title}
                          className="w-full aspect-[2/3] object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        {book.rating && (
                          <div className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 rounded-lg flex items-center gap-1 shadow-lg">
                            <span className="text-xs font-bold">★ {book.rating}</span>
                          </div>
                        )}
                      </div>
                      <div className="p-3 sm:p-4">
                        <h3 className="font-bold text-sm sm:text-base text-gray-900 mb-1 line-clamp-2 group-hover:text-blue-600 transition-colors">
                          {book.title}
                        </h3>
                        <p className="text-xs text-gray-600 mb-1">{book.author_name}</p>
                        {book.publication_year && (
                          <p className="text-xs text-gray-500 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {book.publication_year}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}