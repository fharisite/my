import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, UserX, AlertTriangle, ArrowLeft } from 'lucide-react';
import ModernHeader from '@/components/layout/ModernHeader';
import { toast } from 'sonner';

export default function Settings() {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const handleDeleteAccount = async () => {
    if (confirmText !== 'حذف حسابي') {
      toast.error('الرجاء كتابة "حذف حسابي" للتأكيد');
      return;
    }

    setIsDeleting(true);
    try {
      // In a real implementation, you would call a backend function to delete the account
      // For now, we'll just show a message
      toast.info('جاري معالجة طلب حذف الحساب. سيتم التواصل معك قريباً.');
      setShowDeleteDialog(false);
      setConfirmText('');
      
      // Optionally logout after request
      setTimeout(() => {
        base44.auth.logout();
      }, 2000);
    } catch (error) {
      toast.error('فشل في إرسال طلب الحذف: ' + error.message);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800" dir="rtl">
      <ModernHeader />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-8">الإعدادات</h1>

        {/* Account Info */}
        <Card className="mb-6 dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">معلومات الحساب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="dark:text-gray-300">الاسم الكامل</Label>
              <p className="text-lg font-medium text-gray-900 dark:text-gray-100 mt-1">{user?.full_name}</p>
            </div>
            <div>
              <Label className="dark:text-gray-300">البريد الإلكتروني</Label>
              <p className="text-lg font-medium text-gray-900 dark:text-gray-100 mt-1">{user?.email}</p>
            </div>
            <div>
              <Label className="dark:text-gray-300">الدور</Label>
              <p className="text-lg font-medium text-gray-900 dark:text-gray-100 mt-1">
                {user?.role === 'admin' ? 'مسؤول' : 'مستخدم'}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-red-200 dark:border-red-900 dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="text-red-600 dark:text-red-400 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              منطقة الخطر
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900 rounded-lg p-4">
              <h3 className="font-semibold text-red-900 dark:text-red-300 mb-2">حذف الحساب نهائياً</h3>
              <p className="text-sm text-red-700 dark:text-red-400 mb-4">
                سيؤدي حذف حسابك إلى إزالة جميع بياناتك بشكل دائم، بما في ذلك قوائمك ومراجعاتك ومتابعاتك. 
                هذا الإجراء لا يمكن التراجع عنه.
              </p>
              <Button
                variant="outline"
                className="border-red-600 text-red-600 hover:bg-red-50 dark:border-red-500 dark:text-red-400 dark:hover:bg-red-900/30"
                onClick={() => setShowDeleteDialog(true)}
              >
                <UserX className="w-4 h-4 ml-2" />
                حذف حسابي نهائياً
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent dir="rtl" className="dark:bg-gray-800 dark:border-gray-700">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
              <AlertTriangle className="w-5 h-5" />
              تأكيد حذف الحساب
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900 rounded-lg p-4">
              <p className="text-sm text-red-900 dark:text-red-300 font-medium mb-2">
                تحذير: هذا الإجراء لا يمكن التراجع عنه!
              </p>
              <ul className="text-sm text-red-700 dark:text-red-400 space-y-1 list-disc list-inside">
                <li>سيتم حذف جميع قوائم الكتب الخاصة بك</li>
                <li>سيتم حذف جميع مراجعاتك وتعليقاتك</li>
                <li>سيتم إلغاء جميع متابعاتك</li>
                <li>لن تتمكن من استعادة حسابك أو بياناتك</li>
              </ul>
            </div>

            <div>
              <Label className="dark:text-gray-300">
                للتأكيد، اكتب <strong className="text-red-600 dark:text-red-400">حذف حسابي</strong>
              </Label>
              <Input
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="حذف حسابي"
                className="mt-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setShowDeleteDialog(false);
                setConfirmText('');
              }}
              disabled={isDeleting}
              className="dark:border-gray-600 dark:text-gray-300"
            >
              إلغاء
            </Button>
            <Button
              onClick={handleDeleteAccount}
              disabled={isDeleting || confirmText !== 'حذف حسابي'}
              className="bg-red-600 hover:bg-red-700 text-white dark:bg-red-700 dark:hover:bg-red-800"
            >
              {isDeleting ? (
                <>
                  <span className="animate-spin ml-2">⏳</span>
                  جاري الحذف...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 ml-2" />
                  حذف حسابي نهائياً
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}