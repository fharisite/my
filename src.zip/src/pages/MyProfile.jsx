import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { User, BookMarked, BookOpen, Camera, Save, Loader2, Star, Trash2, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import ModernHeader from '@/components/layout/ModernHeader';

export default function MyProfile() {
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me(),
  });

  const [form, setForm] = useState(null);

  React.useEffect(() => {
    if (user && !form) {
      setForm({
        full_name: user.full_name || '',
        photo: user.photo || '',
        phone: user.phone || '',
        bio: user.bio || '',
      });
    }
  }, [user]);

  const { data: bookLists = [] } = useQuery({
    queryKey: ['myBookLists'],
    queryFn: () => base44.entities.BookList.filter({ owner_email: user?.email }),
    enabled: !!user,
  });

  const { data: listItems = [] } = useQuery({
    queryKey: ['myListItems', bookLists.map(l => l.id).join(',')],
    queryFn: async () => {
      if (!bookLists.length) return [];
      const all = await Promise.all(
        bookLists.map(l => base44.entities.BookListItem.filter({ list_id: l.id }))
      );
      return all.flat();
    },
    enabled: bookLists.length > 0,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['myReviews'],
    queryFn: () => base44.entities.BookReview.filter({ user_email: user?.email }),
    enabled: !!user,
  });

  const { data: allBooks = [] } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['me'] });
      queryClient.invalidateQueries({ queryKey: ['user'] });
      setEditMode(false);
      toast.success('تم تحديث الملف الشخصي');
    },
    onError: () => toast.error('فشل التحديث'),
  });

  const removeFromListMutation = useMutation({
    mutationFn: (id) => base44.entities.BookListItem.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myListItems'] });
      toast.success('تم الحذف من القائمة');
    },
  });

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm(f => ({ ...f, photo: file_url }));
      toast.success('تم رفع الصورة');
    } catch {
      toast.error('فشل رفع الصورة');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSave = () => updateMutation.mutate(form);

  // Derive favorite books (from all lists) and reading history (reviewed books)
  const favBookIds = [...new Set(listItems.map(i => i.book_id))];
  const favBooks = allBooks.filter(b => favBookIds.includes(b.id));
  const reviewedBookIds = reviews.map(r => r.book_id);
  const readBooks = allBooks.filter(b => reviewedBookIds.includes(b.id));

  if (userLoading) return (
    <div className="min-h-screen flex items-center justify-center" dir="rtl">
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#75420e' }} />
    </div>
  );

  if (!user) return (
    <div className="min-h-screen flex items-center justify-center" dir="rtl">
      <Card className="text-center p-12">
        <User className="w-14 h-14 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-600 mb-4">يجب تسجيل الدخول لعرض حسابك</p>
        <Button onClick={() => base44.auth.redirectToLogin()}>تسجيل الدخول</Button>
      </Card>
    </div>
  );

  const roleLabels = { admin: 'مدير', editor: 'محرر', user: 'قارئ' };

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)' }} dir="rtl">
      <ModernHeader />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">

        {/* Profile Header Card */}
        <Card className="mb-8 shadow-xl overflow-hidden">
          <div className="h-28" style={{ background: 'linear-gradient(to left, #75420e, #553b08)' }} />
          <CardContent className="p-6 -mt-14">
            <div className="flex flex-col sm:flex-row gap-5 items-center sm:items-end">
              {/* Avatar */}
              <div className="relative flex-shrink-0">
                {(form?.photo || user.photo) ? (
                  <img
                    src={form?.photo || user.photo}
                    alt={user.full_name}
                    className="w-24 h-24 rounded-full object-cover ring-4 ring-white shadow-lg"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full ring-4 ring-white shadow-lg flex items-center justify-center text-3xl font-bold text-white" style={{ background: 'linear-gradient(to br, #75420e, #a05a20)' }}>
                    {user.full_name?.charAt(0) || '?'}
                  </div>
                )}
                {editMode && (
                  <label className="absolute bottom-0 left-0 w-7 h-7 bg-white rounded-full shadow flex items-center justify-center cursor-pointer hover:bg-gray-100 border">
                    {uploadingPhoto ? <Loader2 className="w-4 h-4 animate-spin text-gray-500" /> : <Camera className="w-4 h-4 text-gray-600" />}
                    <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} disabled={uploadingPhoto} />
                  </label>
                )}
              </div>

              {/* Name & role */}
              <div className="flex-1 text-center sm:text-right">
                <h1 className="text-2xl font-bold text-gray-900">{user.full_name}</h1>
                <p className="text-gray-500 text-sm">{user.email}</p>
                <span className="inline-block mt-1 px-3 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200">
                  {roleLabels[user.role] || 'قارئ'}
                </span>
              </div>

              {/* Stats */}
              <div className="flex gap-4 text-center">
                {[
                  { label: 'مفضلة', value: favBooks.length, icon: <BookMarked className="w-4 h-4" /> },
                  { label: 'مقروءة', value: readBooks.length, icon: <BookOpen className="w-4 h-4" /> },
                  { label: 'تقييمات', value: reviews.length, icon: <Star className="w-4 h-4" /> },
                ].map(s => (
                  <div key={s.label} className="px-4 py-2 rounded-xl bg-gray-50 border min-w-[70px]">
                    <div className="flex items-center justify-center gap-1 text-gray-500 mb-1">{s.icon}</div>
                    <p className="text-xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-xs text-gray-500">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Edit toggle */}
              <Button
                variant={editMode ? 'outline' : 'default'}
                size="sm"
                onClick={() => editMode ? setEditMode(false) : setEditMode(true)}
                className={!editMode ? 'text-white' : ''}
                style={!editMode ? { background: 'linear-gradient(to left, #75420e, #553b08)' } : {}}
              >
                {editMode ? 'إلغاء' : 'تعديل الملف'}
              </Button>
            </div>

            {/* Edit Form */}
            {editMode && form && (
              <div className="mt-6 pt-6 border-t grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-1 block">الاسم الكامل</Label>
                  <Input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} />
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-1 block">رقم الهاتف</Label>
                  <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+966..." />
                </div>
                <div className="sm:col-span-2">
                  <Label className="text-sm font-medium text-gray-700 mb-1 block">نبذة شخصية</Label>
                  <Input value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} placeholder="اكتب نبذة مختصرة عنك..." />
                </div>
                <div className="sm:col-span-2 flex justify-end">
                  <Button
                    onClick={handleSave}
                    disabled={updateMutation.isPending}
                    className="gap-2 text-white"
                    style={{ background: 'linear-gradient(to left, #75420e, #553b08)' }}
                  >
                    {updateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    حفظ التغييرات
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="favorites" dir="rtl">
          <TabsList className="mb-6 w-full sm:w-auto">
            <TabsTrigger value="favorites" className="gap-2">
              <BookMarked className="w-4 h-4" /> المفضلة ({favBooks.length})
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <BookOpen className="w-4 h-4" /> سجل القراءة ({readBooks.length})
            </TabsTrigger>
            <TabsTrigger value="reviews" className="gap-2">
              <Star className="w-4 h-4" /> تقييماتي ({reviews.length})
            </TabsTrigger>
          </TabsList>

          {/* Favorites */}
          <TabsContent value="favorites">
            {favBooks.length === 0 ? (
              <EmptyState icon={<BookMarked className="w-12 h-12 text-gray-300" />} text="لم تضف أي كتاب للمفضلة بعد" link="Books" linkText="تصفح الكتب" />
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {favBooks.map(book => {
                  const item = listItems.find(i => i.book_id === book.id);
                  return (
                    <div key={book.id} className="relative group">
                      <Link to={createPageUrl(`BookDetail?id=${book.id}`)}>
                        <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                          <CardContent className="p-0">
                            <img
                              src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                              alt={book.title}
                              className="w-full aspect-[2/3] object-cover rounded-t-xl"
                            />
                            <div className="p-3">
                              <h3 className="font-semibold text-sm text-gray-900 line-clamp-2">{book.title}</h3>
                              <p className="text-xs text-gray-500 mt-1">{book.author_name}</p>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                      {item && (
                        <button
                          onClick={() => removeFromListMutation.mutate(item.id)}
                          className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white shadow opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center hover:bg-red-50"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-500" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Reading History */}
          <TabsContent value="history">
            {readBooks.length === 0 ? (
              <EmptyState icon={<BookOpen className="w-12 h-12 text-gray-300" />} text="لا يوجد سجل قراءة بعد" link="Books" linkText="ابدأ القراءة" />
            ) : (
              <div className="space-y-3">
                {readBooks.map(book => {
                  const review = reviews.find(r => r.book_id === book.id);
                  return (
                    <Link key={book.id} to={createPageUrl(`BookDetail?id=${book.id}`)}>
                      <Card className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-4 flex gap-4 items-center">
                          <img
                            src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                            alt={book.title}
                            className="w-12 h-16 object-cover rounded shadow"
                          />
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-gray-900 truncate">{book.title}</h3>
                            <p className="text-sm text-gray-500">{book.author_name}</p>
                            {review && (
                              <div className="flex items-center gap-1 mt-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star key={i} className={`w-3.5 h-3.5 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`} />
                                ))}
                              </div>
                            )}
                          </div>
                          <div className="text-xs text-gray-400 flex items-center gap-1 flex-shrink-0">
                            <Calendar className="w-3 h-3" />
                            {review?.created_date ? new Date(review.created_date).toLocaleDateString('ar-SA') : ''}
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* My Reviews */}
          <TabsContent value="reviews">
            {reviews.length === 0 ? (
              <EmptyState icon={<Star className="w-12 h-12 text-gray-300" />} text="لم تكتب أي تقييم بعد" link="Books" linkText="قيّم كتاباً" />
            ) : (
              <div className="space-y-4">
                {reviews.map(review => {
                  const book = allBooks.find(b => b.id === review.book_id);
                  return (
                    <Card key={review.id}>
                      <CardContent className="p-4">
                        <div className="flex gap-4">
                          {book && (
                            <Link to={createPageUrl(`BookDetail?id=${book.id}`)} className="flex-shrink-0">
                              <img
                                src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                                alt={book.title}
                                className="w-12 h-16 object-cover rounded shadow"
                              />
                            </Link>
                          )}
                          <div className="flex-1">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div>
                                <h3 className="font-semibold text-gray-900">{book?.title || 'كتاب محذوف'}</h3>
                                <p className="text-xs text-gray-500">{book?.author_name}</p>
                              </div>
                              <div className="flex items-center gap-0.5 flex-shrink-0">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`} />
                                ))}
                              </div>
                            </div>
                            {review.review_text && (
                              <p className="text-sm text-gray-700 leading-relaxed bg-gray-50 p-3 rounded-lg">
                                {review.review_text}
                              </p>
                            )}
                            <p className="text-xs text-gray-400 mt-2">
                              {review.created_date ? new Date(review.created_date).toLocaleDateString('ar-SA') : ''}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function EmptyState({ icon, text, link, linkText }) {
  return (
    <Card className="text-center py-16 bg-white/50">
      <CardContent>
        <div className="flex justify-center mb-4">{icon}</div>
        <p className="text-gray-500 mb-4">{text}</p>
        <Link to={createPageUrl(link)}>
          <Button variant="outline" size="sm">{linkText}</Button>
        </Link>
      </CardContent>
    </Card>
  );
}