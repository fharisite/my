import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Plus, Pencil, Trash2, Search, FileSpreadsheet, BookOpen, LayoutDashboard, Settings, Download, Loader2, CheckSquare, Square, Copy, Users, Building, BarChart3, TrendingUp, Files } from 'lucide-react';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';

export default function Admin() {
  const urlParams = new URLSearchParams(window.location.search);
  const editBookId = urlParams.get('editBook');
  
  const [showForm, setShowForm] = useState(false);
  const [editingBook, setEditingBook] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [uploadingCover, setUploadingCover] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showCSVImportDialog, setShowCSVImportDialog] = useState(false);
  const [showStatsDialog, setShowStatsDialog] = useState(false);
  const [selectedStats, setSelectedStats] = useState({ type: '', title: '', data: [] });
  const [importData, setImportData] = useState({
    spreadsheetId: '',
    sheetName: ''
  });
  const [csvFile, setCsvFile] = useState(null);
  const [importResult, setImportResult] = useState(null);
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [processingStatus, setProcessingStatus] = useState({ message: '', progress: 0 });
  const [processingTask, setProcessingTask] = useState(false);
  const [selectedBooks, setSelectedBooks] = useState([]);
  const [showBulkEditDialog, setShowBulkEditDialog] = useState(false);
  const [bulkEditData, setBulkEditData] = useState({
    author_id: '',
    publisher_id: '',
    category: ''
  });
  const [formData, setFormData] = useState({
    isbn: '',
    title: '',
    author_id: '',
    author_name: '',
    publisher_id: '',
    publisher_name: '',
    category: '',
    summary: '',
    description: '',
    cover_image: '',
    publication_year: '',
    pages: '',
    rating: '',
    is_featured: false,
    audio_available: false,
    tags: '',
  });

  const queryClient = useQueryClient();

  const { data: books = [], isLoading } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list('-created_date', 200),
  });

  const { data: authors = [] } = useQuery({
    queryKey: ['authors'],
    queryFn: () => base44.entities.Author.list(),
  });

  const { data: publishers = [] } = useQuery({
    queryKey: ['publishers'],
    queryFn: () => base44.entities.Publisher.list(),
  });

  const { data: authorFollows = [] } = useQuery({
    queryKey: ['authorFollows'],
    queryFn: () => base44.entities.AuthorFollow.list(),
  });

  // Auto-open edit form if editBook parameter is in URL
  React.useEffect(() => {
    if (editBookId && books.length > 0 && !editingBook) {
      const bookToEdit = books.find(b => b.id === editBookId);
      if (bookToEdit) {
        handleEdit(bookToEdit);
      }
    }
  }, [editBookId, books]);

  const { data: publisherFollows = [] } = useQuery({
    queryKey: ['publisherFollows'],
    queryFn: () => base44.entities.PublisherFollow.list(),
  });

  const createBookMutation = useMutation({
    mutationFn: (bookData) => base44.entities.Book.create(bookData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      resetForm();
      toast.success('تم إضافة الكتاب بنجاح');
    },
  });

  const updateBookMutation = useMutation({
    mutationFn: ({ id, bookData }) => base44.entities.Book.update(id, bookData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      resetForm();
      toast.success('تم تحديث الكتاب بنجاح');
    },
  });

  const deleteBookMutation = useMutation({
    mutationFn: (id) => base44.entities.Book.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast.success('تم حذف الكتاب بنجاح');
    },
  });

  const bulkUpdateMutation = useMutation({
    mutationFn: async (updates) => {
      const promises = selectedBooks.map(bookId => {
        const book = books.find(b => b.id === bookId);
        const selectedAuthor = updates.author_id ? authors.find(a => a.id === updates.author_id) : null;
        const selectedPublisher = updates.publisher_id ? publishers.find(p => p.id === updates.publisher_id) : null;
        
        const updateData = {};
        if (updates.author_id) {
          updateData.author_id = updates.author_id;
          updateData.author_name = selectedAuthor?.name;
        }
        if (updates.publisher_id) {
          updateData.publisher_id = updates.publisher_id;
          updateData.publisher_name = selectedPublisher?.name;
        }
        if (updates.category) {
          updateData.category = updates.category;
        }
        
        return base44.entities.Book.update(bookId, updateData);
      });
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      setSelectedBooks([]);
      setShowBulkEditDialog(false);
      setBulkEditData({ author_id: '', publisher_id: '', category: '' });
      toast.success(`تم تحديث ${selectedBooks.length} كتاب بنجاح`);
    },
  });

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingCover(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, cover_image: file_url });
      toast.success('تم رفع الصورة بنجاح');
    } catch (error) {
      toast.error('فشل رفع الصورة');
    } finally {
      setUploadingCover(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const selectedAuthor = authors.find(a => a.id === formData.author_id);
    const selectedPublisher = publishers.find(p => p.id === formData.publisher_id);
    
    const bookData = {
      isbn: formData.isbn || undefined,
      title: formData.title,
      author_id: formData.author_id || undefined,
      author_name: selectedAuthor?.name || formData.author_name || undefined,
      publisher_id: formData.publisher_id || undefined,
      publisher_name: selectedPublisher?.name || formData.publisher_name || undefined,
      category: formData.category || undefined,
      summary: formData.summary || undefined,
      description: formData.description || undefined,
      cover_image: formData.cover_image || undefined,
      publication_year: formData.publication_year ? parseInt(formData.publication_year) : undefined,
      pages: formData.pages ? parseInt(formData.pages) : undefined,
      rating: formData.rating ? parseFloat(formData.rating) : undefined,
      is_featured: formData.is_featured,
      audio_available: formData.audio_available,
      tags: formData.tags ? formData.tags.split(',').map(t => t.trim()) : undefined,
    };

    if (editingBook) {
      updateBookMutation.mutate({ id: editingBook.id, bookData });
    } else {
      createBookMutation.mutate(bookData);
    }
  };

  const handleEdit = (book) => {
    setEditingBook(book);
    setFormData({
      isbn: book.isbn || '',
      title: book.title || '',
      author_id: book.author_id || '',
      author_name: book.author_name || '',
      publisher_id: book.publisher_id || '',
      publisher_name: book.publisher_name || '',
      category: book.category || '',
      summary: book.summary || '',
      description: book.description || '',
      cover_image: book.cover_image || '',
      publication_year: book.publication_year || '',
      pages: book.pages || '',
      rating: book.rating || '',
      is_featured: book.is_featured || false,
      audio_available: book.audio_available || false,
      tags: book.tags ? book.tags.join(', ') : '',
    });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (confirm('هل أنت متأكد من حذف هذا الكتاب؟')) {
      deleteBookMutation.mutate(id);
    }
  };

  const handleSelectBook = (bookId) => {
    setSelectedBooks(prev => 
      prev.includes(bookId) 
        ? prev.filter(id => id !== bookId)
        : [...prev, bookId]
    );
  };

  const handleSelectAll = () => {
    if (selectedBooks.length === filteredBooks.length) {
      setSelectedBooks([]);
    } else {
      setSelectedBooks(filteredBooks.map(book => book.id));
    }
  };

  const handleBulkEdit = () => {
    if (selectedBooks.length === 0) {
      toast.error('الرجاء اختيار كتاب واحد على الأقل');
      return;
    }
    setShowBulkEditDialog(true);
  };

  const handleBulkUpdate = () => {
    if (!bulkEditData.author_id && !bulkEditData.publisher_id && !bulkEditData.category) {
      toast.error('الرجاء اختيار حقل واحد على الأقل للتحديث');
      return;
    }
    bulkUpdateMutation.mutate(bulkEditData);
  };

  const handleEnrichContent = async () => {
    if (selectedBooks.length === 0) {
      toast.error('الرجاء اختيار كتاب واحد على الأقل');
      return;
    }

    if (!confirm(`هل تريد إثراء محتوى ${selectedBooks.length} كتاب باستخدام الذكاء الاصطناعي؟\n\nسيتم إنشاء أو تحسين: الملخص، الوصف، والوسوم للكتب التي تحتاج إلى إثراء.`)) {
      return;
    }

    setProcessingTask(true);
    setProcessingStatus({ message: 'جاري تحليل الكتب...', progress: 20 });

    try {
      setProcessingStatus({ message: 'جاري إثراء المحتوى بالذكاء الاصطناعي...', progress: 50 });
      const response = await base44.functions.invoke('enrichBookContent', { bookIds: selectedBooks });
      
      setProcessingStatus({ message: 'تم الانتهاء!', progress: 100 });
      toast.success(response.data?.message || 'تم إثراء المحتوى بنجاح');
      
      queryClient.invalidateQueries({ queryKey: ['books'] });
      setSelectedBooks([]);
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل إثراء المحتوى: ' + error.message);
    } finally {
      setProcessingTask(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const resetForm = () => {
    setFormData({
      isbn: '',
      title: '',
      author_id: '',
      author_name: '',
      publisher_id: '',
      publisher_name: '',
      category: '',
      summary: '',
      description: '',
      cover_image: '',
      publication_year: '',
      pages: '',
      rating: '',
      is_featured: false,
      audio_available: false,
      tags: '',
    });
    setEditingBook(null);
    setShowForm(false);
  };

  const handleImport = async () => {
    if (!importData.spreadsheetId) {
      toast.error('الرجاء إدخال معرف الجدول');
      return;
    }

    setImporting(true);
    setImportResult(null);
    setProcessingStatus({ message: 'جاري الاتصال بـ Google Sheets...', progress: 10 });
    
    try {
      setProcessingStatus({ message: 'جاري قراءة البيانات من الجدول...', progress: 30 });
      const response = await base44.functions.invoke('importBooksFromSheets', importData);
      
      setProcessingStatus({ message: 'جاري حفظ الكتب في قاعدة البيانات...', progress: 70 });
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setProcessingStatus({ message: 'تم الاستيراد بنجاح!', progress: 100 });
      
      const result = response.data;
      setImportResult(result);
      
      // Show detailed results
      if (result?.hasErrors) {
        toast.warning(
          `${result.message}\n\nتم تجاهل ${result.skipped} صف بسبب أخطاء. راجع التفاصيل أدناه.`,
          { duration: 5000 }
        );
      } else {
        toast.success(result?.message || `تم استيراد ${result?.imported || 0} كتاب بنجاح`);
      }
      
      queryClient.invalidateQueries({ queryKey: ['books'] });
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Keep dialog open if there are errors to show
      if (!result?.hasErrors) {
        setShowImportDialog(false);
        setImportData({ spreadsheetId: '', sheetName: '' });
        setImportResult(null);
      }
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل الاستيراد: ' + error.message);
    } finally {
      setImporting(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleImportCSV = async () => {
    if (!csvFile) {
      toast.error('الرجاء اختيار ملف CSV');
      return;
    }

    setImporting(true);
    setProcessingStatus({ message: 'جاري قراءة ملف CSV...', progress: 20 });

    try {
      const formData = new FormData();
      formData.append('file', csvFile);

      setProcessingStatus({ message: 'جاري معالجة البيانات...', progress: 50 });
      
      const response = await fetch(`${base44.functions.getUrl('importBooksFromCSV')}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${await base44.auth.getAccessToken()}`
        },
        body: formData
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'فشل الاستيراد');
      }

      const result = await response.json();
      
      setProcessingStatus({ message: 'جاري حفظ الكتب...', progress: 80 });
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setProcessingStatus({ message: 'تم الاستيراد بنجاح!', progress: 100 });
      
      // Show detailed results
      if (result.hasErrors) {
        toast.warning(
          `${result.message}\n\nتم تجاهل ${result.skipped} صف بسبب أخطاء. راجع التفاصيل في النافذة.`,
          { duration: 5000 }
        );
        console.log('تقرير الأخطاء:', result.errors);
      } else {
        toast.success(result.message);
      }
      
      queryClient.invalidateQueries({ queryKey: ['books'] });
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Keep dialog open if there are errors to show
      if (!result.hasErrors) {
        setShowCSVImportDialog(false);
        setCsvFile(null);
      }
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل الاستيراد: ' + error.message);
    } finally {
      setImporting(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleRemoveDuplicates = async () => {
    if (!confirm('هل أنت متأكد من حذف الكتب المكررة بناءً على ISBN؟ سيتم الاحتفاظ بأقدم نسخة فقط.')) {
      return;
    }

    setProcessingTask(true);
    setProcessingStatus({ message: 'جاري البحث عن الكتب المكررة...', progress: 20 });

    try {
      setProcessingStatus({ message: 'جاري حذف المكررات...', progress: 50 });
      const response = await base44.functions.invoke('removeDuplicateBooks');
      
      setProcessingStatus({ message: 'تم الانتهاء!', progress: 100 });
      toast.success(response.data?.message || 'تم حذف الكتب المكررة');
      
      queryClient.invalidateQueries({ queryKey: ['books'] });
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل حذف المكررات: ' + error.message);
    } finally {
      setProcessingTask(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleImportAuthors = async () => {
    if (!confirm('هل تريد استيراد المؤلفين من الكتب وربطهم تلقائياً؟')) {
      return;
    }

    setProcessingTask(true);
    setProcessingStatus({ message: 'جاري استخراج أسماء المؤلفين من الكتب...', progress: 20 });

    try {
      setProcessingStatus({ message: 'جاري إنشاء المؤلفين الجدد...', progress: 50 });
      const response = await base44.functions.invoke('importAuthorsFromBooks');
      
      setProcessingStatus({ message: 'تم الانتهاء!', progress: 100 });
      toast.success(response.data?.message || 'تم استيراد المؤلفين بنجاح');
      
      queryClient.invalidateQueries({ queryKey: ['authors'] });
      queryClient.invalidateQueries({ queryKey: ['books'] });
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل استيراد المؤلفين: ' + error.message);
    } finally {
      setProcessingTask(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleImportPublishers = async () => {
    if (!confirm('هل تريد استيراد الناشرين من الكتب وربطهم تلقائياً؟')) {
      return;
    }

    setProcessingTask(true);
    setProcessingStatus({ message: 'جاري استخراج أسماء الناشرين من الكتب...', progress: 20 });

    try {
      setProcessingStatus({ message: 'جاري إنشاء الناشرين الجدد...', progress: 50 });
      const response = await base44.functions.invoke('importPublishersFromBooks');
      
      setProcessingStatus({ message: 'تم الانتهاء!', progress: 100 });
      toast.success(response.data?.message || 'تم استيراد الناشرين بنجاح');
      
      queryClient.invalidateQueries({ queryKey: ['publishers'] });
      queryClient.invalidateQueries({ queryKey: ['books'] });
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل استيراد الناشرين: ' + error.message);
    } finally {
      setProcessingTask(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleMergeAuthors = async () => {
    if (!confirm('هل تريد دمج المؤلفين المكررين حسب الاسم؟\n\nسيتم الاحتفاظ بأقدم نسخة وتحديث جميع الكتب المرتبطة.')) {
      return;
    }

    setProcessingTask(true);
    setProcessingStatus({ message: 'جاري البحث عن المؤلفين المكررين...', progress: 20 });

    try {
      setProcessingStatus({ message: 'جاري دمج المؤلفين...', progress: 50 });
      const response = await base44.functions.invoke('mergeAuthorsByName');
      
      setProcessingStatus({ message: 'تم الانتهاء!', progress: 100 });
      toast.success(response.data?.message || 'تم دمج المؤلفين بنجاح');
      
      queryClient.invalidateQueries({ queryKey: ['authors'] });
      queryClient.invalidateQueries({ queryKey: ['books'] });
      queryClient.invalidateQueries({ queryKey: ['authorFollows'] });
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل دمج المؤلفين: ' + error.message);
    } finally {
      setProcessingTask(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleCleanupTempFiles = async () => {
    if (!confirm('هل تريد حذف جميع الملفات المؤقتة القديمة؟')) {
      return;
    }

    setProcessingTask(true);
    setProcessingStatus({ message: 'جاري البحث عن الملفات المؤقتة...', progress: 30 });

    try {
      setProcessingStatus({ message: 'جاري حذف الملفات...', progress: 70 });
      const response = await base44.functions.invoke('cleanupTempFiles');
      
      setProcessingStatus({ message: 'تم الانتهاء!', progress: 100 });
      toast.success(response.data?.message || 'تم تنظيف الملفات المؤقتة');
      
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل التنظيف: ' + error.message);
    } finally {
      setProcessingTask(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const handleExport = async (format) => {
    setExporting(true);
    setProcessingStatus({ message: `جاري جلب ${books.length} كتاب من قاعدة البيانات...`, progress: 20 });
    
    try {
      setProcessingStatus({ message: `جاري تحويل البيانات إلى صيغة ${format.toUpperCase()}...`, progress: 50 });
      
      const response = await base44.functions.invoke('exportBooks', {}, { 
        responseType: 'blob',
        params: { format }
      });
      
      setProcessingStatus({ message: 'جاري تجهيز الملف للتحميل...', progress: 80 });
      
      const blob = new Blob([response.data], { 
        type: format === 'json' ? 'application/json' : 'text/csv; charset=utf-8' 
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = format === 'json' ? 'books.json' : 'books.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      
      setProcessingStatus({ message: 'تم التصدير بنجاح!', progress: 100 });
      toast.success(`تم تصدير ${books.length} كتاب بنجاح`);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      setProcessingStatus({ message: '', progress: 0 });
      toast.error('فشل التصدير: ' + error.message);
    } finally {
      setExporting(false);
      setProcessingStatus({ message: '', progress: 0 });
    }
  };

  const categories = [
    'روايات وقصص',
    'كتب الأدب',
    'كتب تاريخية',
    'كتب دينية',
    'كتب سياسية',
    'كتب علمية',
    'مال وأعمال',
    'علم النفس وتطوير الذات',
    'السيرة الذاتية والمذكرات'
  ];

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (book.author_name && book.author_name.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = filterCategory === 'all' || book.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const openStatsDialog = (type) => {
    let data = [];
    let title = '';
    
    switch(type) {
      case 'books-no-author':
        data = books.filter(b => !b.author_id && !b.author_name);
        title = 'كتب بدون مؤلف';
        break;
      case 'books-no-publisher':
        data = books.filter(b => !b.publisher_id && !b.publisher_name);
        title = 'كتب بدون ناشر';
        break;
      case 'authors-no-books':
        data = authors.filter(a => !books.some(b => b.author_id === a.id));
        title = 'مؤلفون بدون كتب';
        break;
      case 'publishers-no-books':
        data = publishers.filter(p => !books.some(b => b.publisher_id === p.id));
        title = 'ناشرون بدون كتب';
        break;
      case 'books-no-summary':
        data = books.filter(b => !b.summary || b.summary.length < 10);
        title = 'كتب بدون ملخص';
        break;
      case 'books-no-description':
        data = books.filter(b => !b.description || b.description.length < 10);
        title = 'كتب بدون وصف';
        break;
      case 'all-books':
        data = books;
        title = 'جميع الكتب';
        break;
      case 'all-authors':
        data = authors;
        title = 'جميع المؤلفين';
        break;
      case 'all-publishers':
        data = publishers;
        title = 'جميع الناشرين';
        break;
    }
    
    setSelectedStats({ type, title, data });
    setShowStatsDialog(true);
  };

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)'}} dir="rtl">
      {/* Modern Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-lg backdrop-blur-sm bg-white/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            {/* Logo & Title */}
            <div className="flex items-center gap-2 sm:gap-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg" style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}>
                <LayoutDashboard className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl md:text-2xl font-bold" style={{background: 'linear-gradient(to left, #75420e, #553b08)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'}}>
                  لوحة التحكم
                </h1>
                <p className="text-xs sm:text-sm text-gray-500 hidden sm:block">إدارة محتوى مكتبة فهارس</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex items-center gap-1 sm:gap-2">
              <Link to={createPageUrl('Home')}>
                <Button variant="ghost" size="sm" className="gap-1 sm:gap-2 transition-all">
                  <BookOpen className="w-4 h-4" />
                  <span className="hidden lg:inline text-xs sm:text-sm">المكتبة</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Books')}>
                <Button variant="ghost" size="sm" className="gap-1 sm:gap-2 transition-all">
                  <Search className="w-4 h-4" />
                  <span className="hidden lg:inline text-xs sm:text-sm">تصفح الكتب</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Authors')}>
                <Button variant="ghost" size="sm" className="gap-1 sm:gap-2 transition-all">
                  <Users className="w-4 h-4" />
                  <span className="hidden lg:inline text-xs sm:text-sm">المؤلفين</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Publishers')}>
                <Button variant="ghost" size="sm" className="gap-1 sm:gap-2 transition-all">
                  <Building className="w-4 h-4" />
                  <span className="hidden lg:inline text-xs sm:text-sm">الناشرين</span>
                </Button>
              </Link>
            </nav>
          </div>

          {/* Stats Bar */}
          <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-gray-100">
            <div className="grid grid-cols-3 gap-2 sm:gap-4">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg" style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)'}}>
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-white shadow-sm flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" style={{color: '#75420e'}} />
                </div>
                <div className="text-center sm:text-right">
                  <p className="text-[10px] sm:text-xs text-gray-600">إجمالي الكتب</p>
                  <p className="text-base sm:text-xl font-bold text-gray-900">{books.length}</p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg bg-gradient-to-l from-blue-50 to-indigo-50">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-white shadow-sm flex items-center justify-center flex-shrink-0">
                  <span className="text-base sm:text-xl">⭐</span>
                </div>
                <div className="text-center sm:text-right">
                  <p className="text-[10px] sm:text-xs text-gray-600">كتب مميزة</p>
                  <p className="text-base sm:text-xl font-bold text-gray-900">{books.filter(b => b.is_featured).length}</p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg bg-gradient-to-l from-green-50 to-emerald-50">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-white shadow-sm flex items-center justify-center flex-shrink-0">
                  <span className="text-base sm:text-xl">🎧</span>
                </div>
                <div className="text-center sm:text-right">
                  <p className="text-[10px] sm:text-xs text-gray-600">كتب صوتية</p>
                  <p className="text-base sm:text-xl font-bold text-gray-900">{books.filter(b => b.audio_available).length}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Statistics Section */}
        <Card className="mb-6" style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)', borderColor: '#e9e5cd'}}>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <BarChart3 className="w-5 h-5" style={{color: '#75420e'}} />
              <h2 className="text-xl font-bold text-gray-900">إحصائيات المنصة الشاملة</h2>
            </div>
            
            {/* Main Statistics */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
              <div 
                onClick={() => openStatsDialog('all-books')}
                className="bg-white rounded-lg p-4 shadow-sm border-l-4 cursor-pointer hover:shadow-lg transition-shadow" 
                style={{borderColor: '#75420e'}}
              >
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5" style={{color: '#75420e'}} />
                  <p className="text-sm text-gray-600">إجمالي الكتب</p>
                </div>
                <p className="text-3xl font-bold text-gray-900">{books.length}</p>
                <p className="text-xs text-gray-500 mt-1">اضغط للتفاصيل</p>
              </div>
              
              <div 
                onClick={() => openStatsDialog('all-authors')}
                className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-blue-500 cursor-pointer hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <p className="text-sm text-gray-600">إجمالي المؤلفين</p>
                </div>
                <p className="text-3xl font-bold text-gray-900">{authors.length}</p>
                <p className="text-xs text-gray-500 mt-1">اضغط للتفاصيل</p>
              </div>
              
              <div 
                onClick={() => openStatsDialog('all-publishers')}
                className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-green-500 cursor-pointer hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Building className="w-5 h-5 text-green-600" />
                  <p className="text-sm text-gray-600">إجمالي الناشرين</p>
                </div>
                <p className="text-3xl font-bold text-gray-900">{publishers.length}</p>
                <p className="text-xs text-gray-500 mt-1">اضغط للتفاصيل</p>
              </div>
              
              <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-purple-500">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  <p className="text-sm text-gray-600">متابعات المؤلفين</p>
                </div>
                <p className="text-3xl font-bold text-gray-900">{authorFollows.length}</p>
              </div>
              
              <div className="bg-white rounded-lg p-4 shadow-sm border-l-4 border-indigo-500">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-indigo-600" />
                  <p className="text-sm text-gray-600">متابعات الناشرين</p>
                </div>
                <p className="text-3xl font-bold text-gray-900">{publisherFollows.length}</p>
              </div>
            </div>

            {/* Data Quality Statistics */}
            <div className="border-t pt-6 mt-2">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-orange-600" />
                تحليل جودة البيانات
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                {/* Books without author */}
                <div 
                  onClick={() => openStatsDialog('books-no-author')}
                  className="bg-orange-50 rounded-lg p-4 shadow-sm border border-orange-200 cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-4 h-4 text-orange-600" />
                    <p className="text-xs text-orange-700">كتب بلا مؤلف</p>
                  </div>
                  <p className="text-2xl font-bold text-orange-900">
                    {books.filter(b => !b.author_id && !b.author_name).length}
                  </p>
                  <p className="text-[10px] text-orange-600 mt-1">اضغط للتفاصيل</p>
                </div>

                {/* Books without publisher */}
                <div 
                  onClick={() => openStatsDialog('books-no-publisher')}
                  className="bg-red-50 rounded-lg p-4 shadow-sm border border-red-200 cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-4 h-4 text-red-600" />
                    <p className="text-xs text-red-700">كتب بلا ناشر</p>
                  </div>
                  <p className="text-2xl font-bold text-red-900">
                    {books.filter(b => !b.publisher_id && !b.publisher_name).length}
                  </p>
                  <p className="text-[10px] text-red-600 mt-1">اضغط للتفاصيل</p>
                </div>

                {/* Authors without books */}
                <div 
                  onClick={() => openStatsDialog('authors-no-books')}
                  className="bg-blue-50 rounded-lg p-4 shadow-sm border border-blue-200 cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-4 h-4 text-blue-600" />
                    <p className="text-xs text-blue-700">مؤلفون بلا كتب</p>
                  </div>
                  <p className="text-2xl font-bold text-blue-900">
                    {authors.filter(a => !books.some(b => b.author_id === a.id)).length}
                  </p>
                  <p className="text-[10px] text-blue-600 mt-1">اضغط للتفاصيل</p>
                </div>

                {/* Publishers without books */}
                <div 
                  onClick={() => openStatsDialog('publishers-no-books')}
                  className="bg-green-50 rounded-lg p-4 shadow-sm border border-green-200 cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Building className="w-4 h-4 text-green-600" />
                    <p className="text-xs text-green-700">ناشرون بلا كتب</p>
                  </div>
                  <p className="text-2xl font-bold text-green-900">
                    {publishers.filter(p => !books.some(b => b.publisher_id === p.id)).length}
                  </p>
                  <p className="text-[10px] text-green-600 mt-1">اضغط للتفاصيل</p>
                </div>

                {/* Books without summary */}
                <div 
                  onClick={() => openStatsDialog('books-no-summary')}
                  className="bg-yellow-50 rounded-lg p-4 shadow-sm border border-yellow-200 cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-4 h-4 text-yellow-600" />
                    <p className="text-xs text-yellow-700">كتب بلا ملخص</p>
                  </div>
                  <p className="text-2xl font-bold text-yellow-900">
                    {books.filter(b => !b.summary || b.summary.length < 10).length}
                  </p>
                  <p className="text-[10px] text-yellow-600 mt-1">اضغط للتفاصيل</p>
                </div>

                {/* Books without description */}
                <div 
                  onClick={() => openStatsDialog('books-no-description')}
                  className="bg-purple-50 rounded-lg p-4 shadow-sm border border-purple-200 cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-4 h-4 text-purple-600" />
                    <p className="text-xs text-purple-700">كتب بلا وصف</p>
                  </div>
                  <p className="text-2xl font-bold text-purple-900">
                    {books.filter(b => !b.description || b.description.length < 10).length}
                  </p>
                  <p className="text-[10px] text-purple-600 mt-1">اضغط للتفاصيل</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">إدارة الكتب</h1>
          <div className="flex flex-col gap-3">
            {/* Maintenance Tools */}
            <Card className="bg-gradient-to-l from-purple-50 to-indigo-50 border-purple-200">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Settings className="w-4 h-4 text-purple-600" />
                  <h3 className="text-sm font-semibold text-purple-900">أدوات الصيانة</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    onClick={handleRemoveDuplicates}
                    variant="outline"
                    size="sm"
                    disabled={processingTask}
                    className="border-red-600 text-red-600 hover:bg-red-50 text-xs"
                  >
                    <Copy className="w-3 h-3 ml-1" />
                    حذف المكررات
                  </Button>
                  <Button
                    onClick={handleCleanupTempFiles}
                    variant="outline"
                    size="sm"
                    disabled={processingTask}
                    className="border-yellow-600 text-yellow-600 hover:bg-yellow-50 text-xs"
                  >
                    <Files className="w-3 h-3 ml-1" />
                    تنظيف الملفات
                  </Button>
                  <Button
                    onClick={handleImportAuthors}
                    variant="outline"
                    size="sm"
                    disabled={processingTask}
                    className="border-blue-600 text-blue-600 hover:bg-blue-50 text-xs"
                  >
                    <Users className="w-3 h-3 ml-1" />
                    استيراد المؤلفين
                  </Button>
                  <Button
                    onClick={handleImportPublishers}
                    variant="outline"
                    size="sm"
                    disabled={processingTask}
                    className="border-green-600 text-green-600 hover:bg-green-50 text-xs"
                  >
                    <Building className="w-3 h-3 ml-1" />
                    استيراد الناشرين
                  </Button>
                  <Button
                    onClick={handleMergeAuthors}
                    variant="outline"
                    size="sm"
                    disabled={processingTask}
                    className="border-indigo-600 text-indigo-600 hover:bg-indigo-50 text-xs"
                  >
                    <Users className="w-3 h-3 ml-1" />
                    دمج المؤلفين
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
              <Button
                onClick={() => handleExport('csv')}
                variant="outline"
                size="sm"
                disabled={exporting}
                className="border-blue-600 text-blue-600 hover:bg-blue-50 text-xs sm:text-sm disabled:opacity-50"
              >
                {exporting ? <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2 animate-spin" /> : <Download className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />}
                <span className="hidden sm:inline">تصدير CSV</span>
                <span className="sm:hidden">CSV</span>
              </Button>
              <Button
                onClick={() => handleExport('json')}
                variant="outline"
                size="sm"
                disabled={exporting}
                className="border-purple-600 text-purple-600 hover:bg-purple-50 text-xs sm:text-sm disabled:opacity-50"
              >
                {exporting ? <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2 animate-spin" /> : <Download className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />}
                <span className="hidden sm:inline">تصدير JSON</span>
                <span className="sm:hidden">JSON</span>
              </Button>
              <Button
                onClick={() => setShowCSVImportDialog(true)}
                variant="outline"
                size="sm"
                disabled={importing}
                className="border-green-600 text-green-600 hover:bg-green-50 text-xs sm:text-sm disabled:opacity-50"
              >
                <FileSpreadsheet className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />
                <span className="hidden sm:inline">استيراد من CSV</span>
                <span className="sm:hidden">CSV</span>
              </Button>
              <Button
                onClick={() => setShowImportDialog(true)}
                variant="outline"
                size="sm"
                disabled={importing}
                className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 text-xs sm:text-sm disabled:opacity-50"
              >
                <FileSpreadsheet className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />
                <span className="hidden sm:inline">استيراد من Sheets</span>
                <span className="sm:hidden">Sheets</span>
              </Button>
              <Button
                onClick={() => setShowForm(true)}
                size="sm"
                className="text-xs sm:text-sm text-white"
                style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}
              >
                <Plus className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />
                <span className="hidden sm:inline">إضافة كتاب جديد</span>
                <span className="sm:hidden">إضافة كتاب</span>
              </Button>
              <Link to={createPageUrl('ReviewSuggestions')}>
                <Button variant="outline" size="sm">
                  <CheckSquare className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />
                  <span className="hidden sm:inline">مراجعة الاقتراحات</span>
                  <span className="sm:hidden">الاقتراحات</span>
                </Button>
              </Link>
              <Link to={createPageUrl('UserManagement')}>
                <Button variant="outline" size="sm">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 ml-1 sm:ml-2" />
                  <span className="hidden sm:inline">إدارة المستخدمين</span>
                  <span className="sm:hidden">المستخدمون</span>
                </Button>
              </Link>
            </div>
            
            {(exporting || importing || processingTask) && processingStatus.message && (
              <Card className="bg-gradient-to-l from-blue-50 to-indigo-50 border-blue-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                    <p className="text-sm font-medium text-blue-900">{processingStatus.message}</p>
                  </div>
                  <Progress value={processingStatus.progress} className="h-2" />
                  <p className="text-xs text-blue-700 mt-2 text-left">{processingStatus.progress}%</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="ابحث عن كتاب أو مؤلف..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع التصنيفات</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions Bar */}
        {selectedBooks.length > 0 && (
          <Card className="bg-gradient-to-l from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckSquare className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-blue-900">
                    تم تحديد {selectedBooks.length} كتاب
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleEnrichContent}
                    size="sm"
                    className="bg-purple-600 hover:bg-purple-700"
                    disabled={processingTask}
                  >
                    <TrendingUp className="w-4 h-4 ml-2" />
                    إثراء بالذكاء الاصطناعي
                  </Button>
                  <Button
                    onClick={handleBulkEdit}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Pencil className="w-4 h-4 ml-2" />
                    تعديل جماعي
                  </Button>
                  <Button
                    onClick={() => setSelectedBooks([])}
                    variant="outline"
                    size="sm"
                  >
                    إلغاء التحديد
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Books List */}
        <Card>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="text-center py-12">جاري التحميل...</div>
            ) : filteredBooks.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">لا توجد نتائج</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-4 pb-4 border-b">
                  <Checkbox
                    checked={selectedBooks.length === filteredBooks.length}
                    onCheckedChange={handleSelectAll}
                  />
                  <span className="text-sm text-gray-600">تحديد الكل</span>
                </div>
                <div className="space-y-4">
                {filteredBooks.map((book) => (
                  <div key={book.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <Checkbox
                      checked={selectedBooks.includes(book.id)}
                      onCheckedChange={() => handleSelectBook(book.id)}
                    />
                    <img 
                      src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'} 
                      alt={book.title} 
                      className="w-16 h-24 object-cover rounded shadow" 
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{book.title}</h3>
                      <p className="text-gray-600 text-sm">{book.author_name}</p>
                      <div className="flex gap-2 mt-1">
                        {book.category && (
                          <span className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded">
                            {book.category}
                          </span>
                        )}
                        {book.is_featured && (
                          <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">
                            ⭐ مميز
                          </span>
                        )}
                        {book.audio_available && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                            🎧 صوتي
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(book)}>
                        <Pencil className="w-4 h-4 ml-1" />
                        تعديل
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(book.id)} className="text-red-600 hover:text-red-700">
                        <Trash2 className="w-4 h-4 ml-1" />
                        حذف
                      </Button>
                    </div>
                  </div>
                ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Bulk Edit Dialog */}
        <Dialog open={showBulkEditDialog} onOpenChange={setShowBulkEditDialog}>
          <DialogContent className="max-w-xl" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-2xl">تعديل جماعي لـ {selectedBooks.length} كتاب</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-sm text-amber-800">
                  <strong>ملاحظة:</strong> اختر الحقول التي تريد تحديثها. الحقول الفارغة لن يتم تغييرها.
                </p>
              </div>

              <div>
                <Label>المؤلف</Label>
                <Select 
                  value={bulkEditData.author_id} 
                  onValueChange={(value) => setBulkEditData({ ...bulkEditData, author_id: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="اختر المؤلف (اختياري)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>بدون تغيير</SelectItem>
                    {authors.map((author) => (
                      <SelectItem key={author.id} value={author.id}>{author.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>الناشر</Label>
                <Select 
                  value={bulkEditData.publisher_id} 
                  onValueChange={(value) => setBulkEditData({ ...bulkEditData, publisher_id: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="اختر الناشر (اختياري)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>بدون تغيير</SelectItem>
                    {publishers.map((publisher) => (
                      <SelectItem key={publisher.id} value={publisher.id}>{publisher.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>التصنيف</Label>
                <Select 
                  value={bulkEditData.category} 
                  onValueChange={(value) => setBulkEditData({ ...bulkEditData, category: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="اختر التصنيف (اختياري)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>بدون تغيير</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowBulkEditDialog(false);
                    setBulkEditData({ author_id: '', publisher_id: '', category: '' });
                  }}
                >
                  إلغاء
                </Button>
                <Button 
                  onClick={handleBulkUpdate}
                  className="bg-blue-600 hover:bg-blue-700"
                  disabled={bulkUpdateMutation.isPending}
                >
                  {bulkUpdateMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري التحديث...
                    </>
                  ) : (
                    <>
                      <CheckSquare className="w-4 h-4 ml-2" />
                      تحديث {selectedBooks.length} كتاب
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* CSV Import Dialog */}
        <Dialog open={showCSVImportDialog} onOpenChange={setShowCSVImportDialog}>
          <DialogContent className="max-w-xl" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-2xl">استيراد الكتب من ملف CSV</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800 mb-2">
                  <strong>تنسيق الملف المطلوب:</strong>
                </p>
                <p className="text-xs text-blue-700 leading-relaxed">
                  يجب أن يحتوي ملف CSV على الأعمدة التالية بالترتيب:<br/>
                  ISBN | العنوان | المؤلف | الناشر | التصنيف | الملخص | الوصف | رابط الغلاف | سنة النشر | عدد الصفحات | التقييم | الوسوم | مميز | صوتي
                </p>
              </div>

              <div>
                <Label>اختر ملف CSV *</Label>
                <Input
                  type="file"
                  accept=".csv"
                  onChange={(e) => setCsvFile(e.target.files[0])}
                  className="mt-1"
                />
                {csvFile && (
                  <p className="text-xs text-gray-500 mt-1">
                    الملف المحدد: {csvFile.name}
                  </p>
                )}
              </div>

              {importing && processingStatus.message && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                    <p className="text-sm font-medium text-blue-900">{processingStatus.message}</p>
                  </div>
                  <Progress value={processingStatus.progress} className="h-2" />
                  <p className="text-xs text-blue-700 mt-2 text-left">{processingStatus.progress}%</p>
                </div>
              )}

              <div className="flex gap-3 justify-end pt-4 border-t">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowCSVImportDialog(false);
                    setCsvFile(null);
                  }}
                  disabled={importing}
                >
                  إلغاء
                </Button>
                <Button 
                  onClick={handleImportCSV}
                  className="bg-green-600 hover:bg-green-700"
                  disabled={importing || !csvFile}
                >
                  {importing ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري الاستيراد...
                    </>
                  ) : (
                    'استيراد الكتب'
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Google Sheets Import Dialog */}
        <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
          <DialogContent className="max-w-xl" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-2xl">استيراد الكتب من Google Sheets</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800 mb-2">
                  <strong>تنسيق الجدول المطلوب:</strong>
                </p>
                <p className="text-xs text-blue-700 leading-relaxed">
                  يجب أن يحتوي الجدول على الأعمدة التالية بالترتيب:<br/>
                  ISBN | العنوان | المؤلف | الناشر | التصنيف | الملخص | الوصف | رابط الغلاف | سنة النشر | عدد الصفحات | التقييم | الوسوم | مميز | صوتي
                </p>
              </div>

              <div>
                <Label>معرف جدول Google Sheets *</Label>
                <Input
                  value={importData.spreadsheetId}
                  onChange={(e) => setImportData({ ...importData, spreadsheetId: e.target.value })}
                  placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  المعرف الموجود في رابط الجدول بعد /d/
                </p>
              </div>

              <div>
                <Label>اسم الورقة (اختياري)</Label>
                <Input
                  value={importData.sheetName}
                  onChange={(e) => setImportData({ ...importData, sheetName: e.target.value })}
                  placeholder="Sheet1"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  اتركه فارغاً لاستخدام الورقة الأولى
                </p>
              </div>

              {importing && processingStatus.message && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                    <p className="text-sm font-medium text-blue-900">{processingStatus.message}</p>
                  </div>
                  <Progress value={processingStatus.progress} className="h-2" />
                  <p className="text-xs text-blue-700 mt-2 text-left">{processingStatus.progress}%</p>
                </div>
              )}

              {importResult && importResult.hasErrors && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4 max-h-64 overflow-y-auto">
                  <h4 className="font-semibold text-red-900 mb-3">تقرير الأخطاء ({importResult.errors.length})</h4>
                  <div className="space-y-2">
                    {importResult.errors.map((error, idx) => (
                      <div key={idx} className="bg-white p-3 rounded border border-red-100">
                        <p className="text-sm font-medium text-red-800">الصف {error.row}: {error.error}</p>
                        <p className="text-xs text-gray-600 mt-1">البيانات: {error.data}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {importResult && !importResult.hasErrors && importResult.imported > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                  <p className="text-green-800 font-medium">✓ {importResult.message}</p>
                </div>
              )}

              <div className="flex gap-3 justify-end pt-4 border-t">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowImportDialog(false);
                    setImportResult(null);
                    setImportData({ spreadsheetId: '', sheetName: '' });
                  }}
                  disabled={importing}
                >
                  {importResult?.hasErrors ? 'إغلاق' : 'إلغاء'}
                </Button>
                {!importResult && (
                  <Button 
                    onClick={handleImport}
                    className="bg-green-600 hover:bg-green-700"
                    disabled={importing}
                  >
                    {importing ? (
                      <>
                        <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                        جاري الاستيراد...
                      </>
                    ) : (
                      'استيراد الكتب'
                    )}
                  </Button>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Statistics Details Dialog */}
        <Dialog open={showStatsDialog} onOpenChange={setShowStatsDialog}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-2xl">{selectedStats.title}</DialogTitle>
              <p className="text-sm text-gray-500">إجمالي: {selectedStats.data.length} عنصر</p>
            </DialogHeader>
            <div className="overflow-y-auto max-h-[60vh]">
              {selectedStats.data.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">لا توجد بيانات</p>
                </div>
              ) : selectedStats.type.includes('books') ? (
                <div className="space-y-3">
                  {selectedStats.data.map((book) => (
                    <div key={book.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
                      <img 
                        src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'} 
                        alt={book.title}
                        className="w-12 h-16 object-cover rounded shadow"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{book.title}</h4>
                        <p className="text-sm text-gray-600">{book.author_name || 'بدون مؤلف'}</p>
                        <p className="text-xs text-gray-500">{book.publisher_name || 'بدون ناشر'}</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => {
                          setShowStatsDialog(false);
                          handleEdit(book);
                        }}
                      >
                        <Pencil className="w-4 h-4 ml-1" />
                        تعديل
                      </Button>
                    </div>
                  ))}
                </div>
              ) : selectedStats.type.includes('authors') ? (
                <div className="space-y-3">
                  {selectedStats.data.map((author) => (
                    <div key={author.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
                      {author.photo && (
                        <img 
                          src={author.photo} 
                          alt={author.name}
                          className="w-12 h-12 object-cover rounded-full shadow"
                        />
                      )}
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{author.name}</h4>
                        {author.nationality && (
                          <p className="text-sm text-gray-600">{author.nationality}</p>
                        )}
                        {author.birth_year && (
                          <p className="text-xs text-gray-500">مواليد {author.birth_year}</p>
                        )}
                      </div>
                      <Link to={createPageUrl(`AuthorDetail?id=${author.id}`)}>
                        <Button variant="outline" size="sm">
                          عرض التفاصيل
                        </Button>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : selectedStats.type.includes('publishers') ? (
                <div className="space-y-3">
                  {selectedStats.data.map((publisher) => (
                    <div key={publisher.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
                      {publisher.logo && (
                        <img 
                          src={publisher.logo} 
                          alt={publisher.name}
                          className="w-12 h-12 object-cover rounded shadow"
                        />
                      )}
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{publisher.name}</h4>
                        {publisher.country && (
                          <p className="text-sm text-gray-600">{publisher.country}</p>
                        )}
                        {publisher.founded_year && (
                          <p className="text-xs text-gray-500">تأسست {publisher.founded_year}</p>
                        )}
                      </div>
                      <Link to={createPageUrl(`PublisherDetail?id=${publisher.id}`)}>
                        <Button variant="outline" size="sm">
                          عرض التفاصيل
                        </Button>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
            <div className="flex justify-end pt-4 border-t">
              <Button variant="outline" onClick={() => setShowStatsDialog(false)}>
                إغلاق
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Form Dialog */}
        <Dialog open={showForm} onOpenChange={(open) => !open && resetForm()}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-2xl">{editingBook ? 'تعديل الكتاب' : 'إضافة كتاب جديد'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">المعلومات الأساسية</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>العنوان *</Label>
                    <Input
                      required
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>ISBN</Label>
                    <Input
                      value={formData.isbn}
                      onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label>الملخص</Label>
                  <Textarea
                    rows={3}
                    value={formData.summary}
                    onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                    className="mt-1"
                    placeholder="ملخص مختصر عن الكتاب..."
                  />
                </div>

                <div>
                  <Label>الوصف التفصيلي</Label>
                  <Textarea
                    rows={5}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="mt-1"
                    placeholder="وصف مفصل للكتاب ومحتواه..."
                  />
                </div>
              </div>

              {/* Author & Publisher */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">المؤلف والناشر</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>المؤلف</Label>
                    <Select value={formData.author_id} onValueChange={(value) => {
                      const selectedAuthor = authors.find(a => a.id === value);
                      setFormData({ 
                        ...formData, 
                        author_id: value,
                        author_name: selectedAuthor?.name || ''
                      });
                    }}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="اختر المؤلف" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>بدون مؤلف</SelectItem>
                        {authors.map((author) => (
                          <SelectItem key={author.id} value={author.id}>{author.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {formData.author_id && (
                      <p className="text-xs text-gray-500 mt-1">المؤلف المحدد: {formData.author_name}</p>
                    )}
                    <Input
                      placeholder="أو أدخل اسم المؤلف يدوياً"
                      value={formData.author_name}
                      onChange={(e) => setFormData({ ...formData, author_name: e.target.value, author_id: '' })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>الناشر</Label>
                    <Select value={formData.publisher_id} onValueChange={(value) => {
                      const selectedPublisher = publishers.find(p => p.id === value);
                      setFormData({ 
                        ...formData, 
                        publisher_id: value,
                        publisher_name: selectedPublisher?.name || ''
                      });
                    }}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="اختر الناشر" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>بدون ناشر</SelectItem>
                        {publishers.map((publisher) => (
                          <SelectItem key={publisher.id} value={publisher.id}>{publisher.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {formData.publisher_id && (
                      <p className="text-xs text-gray-500 mt-1">الناشر المحدد: {formData.publisher_name}</p>
                    )}
                    <Input
                      placeholder="أو أدخل اسم الناشر يدوياً"
                      value={formData.publisher_name}
                      onChange={(e) => setFormData({ ...formData, publisher_name: e.target.value, publisher_id: '' })}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Details */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">تفاصيل الكتاب</h3>
                
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>التصنيف</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="اختر التصنيف" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>سنة النشر</Label>
                    <Input
                      type="number"
                      value={formData.publication_year}
                      onChange={(e) => setFormData({ ...formData, publication_year: e.target.value })}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label>عدد الصفحات</Label>
                    <Input
                      type="number"
                      value={formData.pages}
                      onChange={(e) => setFormData({ ...formData, pages: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>التقييم (0-5)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      min="0"
                      max="5"
                      value={formData.rating}
                      onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label>الوسوم (مفصولة بفاصلة)</Label>
                    <Input
                      placeholder="مثال: رواية, أدب, خيال"
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* Cover Image */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">صورة الغلاف</h3>
                
                <div className="flex gap-4 items-start">
                  {formData.cover_image && (
                    <img src={formData.cover_image} alt="غلاف الكتاب" className="w-32 h-48 object-cover rounded shadow" />
                  )}
                  <div className="flex-1 space-y-2">
                    <div>
                      <Label>رفع صورة الغلاف</Label>
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleCoverUpload}
                        disabled={uploadingCover}
                        className="mt-1"
                      />
                      {uploadingCover && <p className="text-sm text-gray-500 mt-1">جاري الرفع...</p>}
                    </div>
                    <div>
                      <Label>أو أدخل رابط الصورة</Label>
                      <Input
                        value={formData.cover_image}
                        onChange={(e) => setFormData({ ...formData, cover_image: e.target.value })}
                        placeholder="https://..."
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Options */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">خيارات إضافية</h3>
                
                <div className="flex gap-6">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.is_featured}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_featured: checked })}
                    />
                    <Label>كتاب مميز ⭐</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.audio_available}
                      onCheckedChange={(checked) => setFormData({ ...formData, audio_available: checked })}
                    />
                    <Label>متوفر كصوتي 🎧</Label>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t">
                <Button type="button" variant="outline" onClick={resetForm}>
                  إلغاء
                </Button>
                <Button type="submit" className="text-white" style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}>
                  {editingBook ? 'تحديث الكتاب' : 'إضافة الكتاب'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}