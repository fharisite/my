import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, Users, Shield, ShieldOff, Crown, BookOpen, User, LayoutDashboard, Filter } from 'lucide-react';
import { toast } from 'sonner';
import ModernHeader from '@/components/layout/ModernHeader';

const ROLE_CONFIG = {
  admin:  { label: 'مدير',   color: 'bg-red-100 text-red-700 border-red-200',    icon: <Crown className="w-3 h-3" /> },
  editor: { label: 'محرر',   color: 'bg-blue-100 text-blue-700 border-blue-200',  icon: <BookOpen className="w-3 h-3" /> },
  user:   { label: 'قارئ',   color: 'bg-gray-100 text-gray-700 border-gray-200',  icon: <User className="w-3 h-3" /> },
};

export default function UserManagement() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [editingUser, setEditingUser] = useState(null);
  const [editRole, setEditRole] = useState('');

  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list('-created_date', 200),
    enabled: currentUser?.role === 'admin',
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.User.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('تم تحديث بيانات المستخدم');
      setEditingUser(null);
    },
    onError: () => toast.error('فشل تحديث البيانات'),
  });

  const handleToggleBan = (user) => {
    const action = user.is_banned ? 'تفعيل' : 'حظر';
    if (!confirm(`هل أنت متأكد من ${action} حساب ${user.full_name}؟`)) return;
    updateMutation.mutate({ id: user.id, data: { is_banned: !user.is_banned } });
  };

  const handleSaveRole = () => {
    if (!editRole) return;
    updateMutation.mutate({ id: editingUser.id, data: { role: editRole } });
  };

  const filtered = users.filter(u => {
    const matchSearch = !search ||
      u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase());
    const matchRole = filterRole === 'all' || u.role === filterRole;
    const matchStatus = filterStatus === 'all' ||
      (filterStatus === 'active' && !u.is_banned) ||
      (filterStatus === 'banned' && u.is_banned);
    return matchSearch && matchRole && matchStatus;
  });

  if (currentUser && currentUser.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <Card className="text-center p-12">
          <Shield className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-800 mb-2">غير مصرح لك</h2>
          <p className="text-gray-500 mb-6">هذه الصفحة للمسؤولين فقط</p>
          <Link to={createPageUrl('Home')}><Button>العودة للرئيسية</Button></Link>
        </Card>
      </div>
    );
  }

  // Stats
  const totalAdmin  = users.filter(u => u.role === 'admin').length;
  const totalEditor = users.filter(u => u.role === 'editor').length;
  const totalUser   = users.filter(u => u.role === 'user' || !u.role).length;
  const totalBanned = users.filter(u => u.is_banned).length;

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)' }} dir="rtl">
      <ModernHeader />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center shadow-lg" style={{ background: 'linear-gradient(to left, #75420e, #553b08)' }}>
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">إدارة المستخدمين</h1>
              <p className="text-sm text-gray-500">{users.length} مستخدم مسجل</p>
            </div>
          </div>
          <Link to={createPageUrl('Admin')}>
            <Button variant="outline" size="sm" className="gap-2">
              <LayoutDashboard className="w-4 h-4" />
              لوحة التحكم
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'مديرون',  count: totalAdmin,  color: 'bg-red-50 border-red-200',   text: 'text-red-700',   icon: <Crown className="w-5 h-5 text-red-500" /> },
            { label: 'محررون',  count: totalEditor, color: 'bg-blue-50 border-blue-200', text: 'text-blue-700',  icon: <BookOpen className="w-5 h-5 text-blue-500" /> },
            { label: 'قراء',    count: totalUser,   color: 'bg-gray-50 border-gray-200', text: 'text-gray-700',  icon: <User className="w-5 h-5 text-gray-500" /> },
            { label: 'محظورون', count: totalBanned, color: 'bg-orange-50 border-orange-200', text: 'text-orange-700', icon: <ShieldOff className="w-5 h-5 text-orange-500" /> },
          ].map(s => (
            <Card key={s.label} className={`border ${s.color}`}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center shadow-sm">{s.icon}</div>
                <div>
                  <p className="text-xs text-gray-500">{s.label}</p>
                  <p className={`text-2xl font-bold ${s.text}`}>{s.count}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="ابحث بالاسم أو البريد..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={filterRole} onValueChange={setFilterRole}>
                <SelectTrigger className="w-40">
                  <Filter className="w-4 h-4 ml-1 text-gray-400" />
                  <SelectValue placeholder="الدور" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأدوار</SelectItem>
                  <SelectItem value="admin">مدير</SelectItem>
                  <SelectItem value="editor">محرر</SelectItem>
                  <SelectItem value="user">قارئ</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="banned">محظور</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="text-center py-16 text-gray-500">جاري التحميل...</div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16">
                <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">لا توجد نتائج</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50 text-right">
                      <th className="px-6 py-3 text-sm font-semibold text-gray-600">المستخدم</th>
                      <th className="px-6 py-3 text-sm font-semibold text-gray-600">البريد الإلكتروني</th>
                      <th className="px-6 py-3 text-sm font-semibold text-gray-600">الدور</th>
                      <th className="px-6 py-3 text-sm font-semibold text-gray-600">الحالة</th>
                      <th className="px-6 py-3 text-sm font-semibold text-gray-600">تاريخ التسجيل</th>
                      <th className="px-6 py-3 text-sm font-semibold text-gray-600">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filtered.map(u => {
                      const role = ROLE_CONFIG[u.role] || ROLE_CONFIG.user;
                      const isSelf = u.email === currentUser?.email;
                      return (
                        <tr key={u.id} className={`hover:bg-gray-50 transition-colors ${u.is_banned ? 'opacity-60 bg-red-50/30' : ''}`}>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-sm" style={{ background: 'linear-gradient(to bottom right, #75420e, #a05a20)' }}>
                                {u.full_name?.charAt(0) || '?'}
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 text-sm">{u.full_name || 'بدون اسم'}</p>
                                {isSelf && <span className="text-xs text-green-600 font-medium">(أنت)</span>}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">{u.email}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${role.color}`}>
                              {role.icon}
                              {role.label}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            {u.is_banned ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700 border border-red-200">
                                <ShieldOff className="w-3 h-3" /> محظور
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 border border-green-200">
                                <Shield className="w-3 h-3" /> نشط
                              </span>
                            )}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500">
                            {u.created_date ? new Date(u.created_date).toLocaleDateString('ar-SA') : '—'}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={isSelf}
                                onClick={() => { setEditingUser(u); setEditRole(u.role || 'user'); }}
                                className="text-xs h-8"
                              >
                                تعديل الدور
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={isSelf || updateMutation.isPending}
                                onClick={() => handleToggleBan(u)}
                                className={`text-xs h-8 ${u.is_banned ? 'text-green-600 border-green-300 hover:bg-green-50' : 'text-red-600 border-red-300 hover:bg-red-50'}`}
                              >
                                {u.is_banned ? 'تفعيل' : 'حظر'}
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Edit Role Dialog */}
      <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل دور المستخدم</DialogTitle>
          </DialogHeader>
          {editingUser && (
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-sm" style={{ background: 'linear-gradient(to bottom right, #75420e, #a05a20)' }}>
                  {editingUser.full_name?.charAt(0) || '?'}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{editingUser.full_name}</p>
                  <p className="text-sm text-gray-500">{editingUser.email}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-700 mb-2">اختر الدور الجديد</p>
                <div className="space-y-2">
                  {Object.entries(ROLE_CONFIG).map(([key, cfg]) => (
                    <label
                      key={key}
                      className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${editRole === key ? 'border-amber-400 bg-amber-50' : 'border-gray-200 hover:bg-gray-50'}`}
                    >
                      <input
                        type="radio"
                        name="role"
                        value={key}
                        checked={editRole === key}
                        onChange={() => setEditRole(key)}
                        className="accent-amber-600"
                      />
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${cfg.color}`}>
                        {cfg.icon} {cfg.label}
                      </span>
                      <span className="text-sm text-gray-600">
                        {key === 'admin' && 'صلاحيات كاملة على المنصة'}
                        {key === 'editor' && 'إضافة وتعديل المحتوى'}
                        {key === 'user'  && 'تصفح وقراءة الكتب'}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setEditingUser(null)}>
                  إلغاء
                </Button>
                <Button
                  className="flex-1 text-white"
                  style={{ background: 'linear-gradient(to left, #75420e, #553b08)' }}
                  onClick={handleSaveRole}
                  disabled={updateMutation.isPending}
                >
                  حفظ التغييرات
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}