import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, BookOpen, Search, ArrowUpDown } from 'lucide-react';
import ModernHeader from '@/components/layout/ModernHeader';

export default function Authors() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('books'); // books, name, followers

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: authors = [], isLoading: loadingAuthors } = useQuery({
    queryKey: ['authors'],
    queryFn: () => base44.entities.Author.list(),
  });

  const { data: books = [], isLoading: loadingBooks } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
  });

  const { data: authorFollows = [] } = useQuery({
    queryKey: ['authorFollows'],
    queryFn: () => base44.entities.AuthorFollow.list(),
  });

  // Calculate book count and followers for each author
  const authorsWithStats = authors.map(author => {
    const bookCount = books.filter(book => book.author_id === author.id).length;
    const followerCount = authorFollows.filter(follow => follow.author_id === author.id).length;
    return {
      ...author,
      bookCount,
      followerCount
    };
  });

  // Filter and sort authors
  const filteredAuthors = authorsWithStats
    .filter(author => 
      author.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      author.nationality?.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'books') {
        return b.bookCount - a.bookCount;
      } else if (sortBy === 'name') {
        return a.name.localeCompare(b.name, 'ar');
      } else if (sortBy === 'followers') {
        return b.followerCount - a.followerCount;
      }
      return 0;
    });

  const isLoading = loadingAuthors || loadingBooks;

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)'}} dir="rtl">
      <ModernHeader />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">المؤلفون</h1>
            <p className="text-gray-600">استكشف المؤلفين وإبداعاتهم الأدبية</p>
          </div>
          {user?.role === 'admin' && (
            <Link to={createPageUrl('ManageAuthors')}>
              <Button className="text-white" style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}>
                إدارة المؤلفين
              </Button>
            </Link>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)'}}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-white shadow-sm flex items-center justify-center">
                  <Users className="w-6 h-6" style={{color: '#75420e'}} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">إجمالي المؤلفين</p>
                  <p className="text-2xl font-bold text-gray-900">{authors.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-l from-blue-50 to-indigo-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-white shadow-sm flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">إجمالي الكتب</p>
                  <p className="text-2xl font-bold text-gray-900">{books.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-l from-green-50 to-emerald-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-white shadow-sm flex items-center justify-center">
                  <span className="text-2xl">👥</span>
                </div>
                <div>
                  <p className="text-sm text-gray-600">إجمالي المتابعات</p>
                  <p className="text-2xl font-bold text-gray-900">{authorFollows.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Sort */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="ابحث عن مؤلف..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-48">
                  <ArrowUpDown className="w-4 h-4 ml-2" />
                  <SelectValue placeholder="ترتيب حسب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="books">عدد الكتب</SelectItem>
                  <SelectItem value="name">الاسم</SelectItem>
                  <SelectItem value="followers">عدد المتابعين</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Authors Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="w-20 h-20 bg-gray-200 rounded-full mx-auto mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3 mx-auto mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredAuthors.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">لا توجد نتائج</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAuthors.map((author) => (
              <Link key={author.id} to={createPageUrl(`AuthorDetail?id=${author.id}`)}>
                <Card className="hover:shadow-xl transition-all hover:scale-105 cursor-pointer h-full">
                  <CardContent className="p-6">
                    <div className="text-center mb-4">
                      {author.photo ? (
                        <img 
                          src={author.photo} 
                          alt={author.name}
                          className="w-20 h-20 object-cover rounded-full shadow-lg mx-auto mb-4"
                        />
                      ) : (
                        <div className="w-20 h-20 rounded-full flex items-center justify-center shadow-lg mx-auto mb-4" style={{background: 'linear-gradient(to left, #e9e5cd, #f5f3e8)'}}>
                          <Users className="w-10 h-10" style={{color: '#75420e'}} />
                        </div>
                      )}
                      <h3 className="font-bold text-lg text-gray-900 mb-1">{author.name}</h3>
                      {author.nationality && (
                        <p className="text-sm text-gray-600 mb-1">{author.nationality}</p>
                      )}
                      {author.birth_year && (
                        <p className="text-xs text-gray-500">مواليد {author.birth_year}</p>
                      )}
                    </div>

                    {author.bio && (
                      <p className="text-sm text-gray-700 mb-4 line-clamp-2 text-center">
                        {author.bio}
                      </p>
                    )}

                    <div className="flex items-center justify-center gap-6 pt-4 border-t">
                      <div className="flex items-center gap-2 text-sm">
                        <BookOpen className="w-4 h-4 text-blue-600" />
                        <span className="font-semibold">{author.bookCount}</span>
                        <span className="text-gray-600">كتاب</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-xl">👥</span>
                        <span className="font-semibold">{author.followerCount}</span>
                        <span className="text-gray-600">متابع</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}