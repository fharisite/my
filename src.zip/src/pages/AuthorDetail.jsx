import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Calendar, BookOpen, Edit, UserPlus, UserCheck, Users, TrendingUp, Headphones, Star, Globe } from 'lucide-react';
import ModernHeader from '../components/layout/ModernHeader';
import AISummarySection from '../components/ai/AISummarySection';

export default function AuthorDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const authorId = urlParams.get('id');
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: authors = [] } = useQuery({
    queryKey: ['authors'],
    queryFn: () => base44.entities.Author.list(),
  });

  const { data: books = [] } = useQuery({
    queryKey: ['books'],
    queryFn: () => base44.entities.Book.list(),
  });

  const { data: follows = [] } = useQuery({
    queryKey: ['authorFollows', authorId],
    queryFn: () => base44.entities.AuthorFollow.filter({ author_id: authorId }),
  });

  const followMutation = useMutation({
    mutationFn: (data) => base44.entities.AuthorFollow.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['authorFollows', authorId] });
      toast.success('تمت المتابعة بنجاح');
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: (id) => base44.entities.AuthorFollow.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['authorFollows', authorId] });
      toast.success('تم إلغاء المتابعة');
    },
  });

  const [authorAiSummary, setAuthorAiSummary] = useState(null);
  const author = authors.find(a => a.id === authorId);
  const authorWithSummary = author ? { ...author, ai_summary: authorAiSummary ?? author.ai_summary } : author;
  const authorBooks = books.filter(b => b.author_id === authorId);
  const isFollowing = follows.find(f => f.follower_email === user?.email);
  
  // Calculate additional stats
  const totalPages = authorBooks.reduce((sum, book) => sum + (book.pages || 0), 0);
  const avgRating = authorBooks.length > 0 
    ? (authorBooks.reduce((sum, book) => sum + (book.rating || 0), 0) / authorBooks.length).toFixed(1)
    : 0;
  const featuredBooks = authorBooks.filter(b => b.is_featured).length;
  const audioBooks = authorBooks.filter(b => b.audio_available).length;

  const handleFollowToggle = () => {
    if (!user) {
      toast.error('يجب تسجيل الدخول أولاً');
      return;
    }
    if (isFollowing) {
      unfollowMutation.mutate(isFollowing.id);
    } else {
      followMutation.mutate({
        author_id: authorId,
        follower_email: user.email,
      });
    }
  };

  if (!author) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <p className="text-gray-600 mb-4">المؤلف غير موجود</p>
          <Link to={createPageUrl('Home')}>
            <Button>العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(to bottom right, #e9e5cd, #ffffff)'}} dir="rtl">
      <ModernHeader />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Author Info */}
        <Card className="mb-12 shadow-2xl overflow-hidden">
          <div className="h-32" style={{background: 'linear-gradient(to left, #75420e, #553b08)'}}></div>
          <CardContent className="p-6 sm:p-8 -mt-16">
            <div className="flex flex-col md:flex-row gap-6 md:gap-8">
              {/* Author Photo */}
              <div className="flex-shrink-0 mx-auto md:mx-0">
                {author.photo ? (
                  <img
                    src={author.photo}
                    alt={author.name}
                    className="w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 object-cover rounded-full shadow-2xl ring-4 ring-white"
                  />
                ) : (
                  <div className="w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 bg-gradient-to-br from-orange-400 to-amber-500 rounded-full shadow-2xl ring-4 ring-white flex items-center justify-center">
                    <span className="text-6xl md:text-7xl">👤</span>
                  </div>
                )}
              </div>

              {/* Author Details */}
              <div className="flex-1 text-center md:text-right">
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-3">{author.name}</h1>
                
                {/* Quick Stats */}
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 sm:gap-4 mb-6">
                  {author.nationality && (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{background: '#e9e5cd'}}>
                      <MapPin className="w-4 h-4" style={{color: '#75420e'}} />
                      <span className="text-sm font-medium text-gray-700">{author.nationality}</span>
                    </div>
                  )}
                  {author.birth_year && (
                    <div className="flex items-center gap-2 bg-blue-50 px-3 py-1.5 rounded-full">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">مواليد {author.birth_year}</span>
                    </div>
                  )}
                </div>

                {/* Statistics Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
                  <div className="rounded-xl p-4 border text-center" style={{background: 'linear-gradient(to bottom right, #e9e5cd, #f5f3e8)', borderColor: '#e9e5cd'}}>
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <BookOpen className="w-5 h-5" style={{color: '#75420e'}} />
                      <span className="text-xs text-gray-600 font-medium">الكتب</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{authorBooks.length}</p>
                  </div>
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Users className="w-5 h-5 text-blue-600" />
                      <span className="text-xs text-gray-600 font-medium">المتابعون</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{follows.length}</p>
                  </div>
                  <div className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-xl p-4 border border-yellow-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Star className="w-5 h-5 text-yellow-500" />
                      <span className="text-xs text-gray-600 font-medium">التقييم</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{avgRating}</p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-100 text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Headphones className="w-5 h-5 text-purple-600" />
                      <span className="text-xs text-gray-600 font-medium">صوتي</span>
                    </div>
                    <p className="text-2xl sm:text-3xl font-bold text-gray-900">{audioBooks}</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                  <Button
                    onClick={handleFollowToggle}
                    size="lg"
                    variant={isFollowing ? "outline" : "default"}
                    className={`shadow-lg ${!isFollowing && "text-white"}`}
                    style={!isFollowing ? {background: 'linear-gradient(to left, #75420e, #553b08)'} : {}}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-5 h-5 ml-2" />
                        تمت المتابعة
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-5 h-5 ml-2" />
                        متابعة المؤلف
                      </>
                    )}
                  </Button>
                  {user?.role === 'admin' ? (
                    <Link to={createPageUrl(`AuthorsPublishers?editAuthor=${authorId}`)}>
                      <Button size="lg" className="bg-blue-600 hover:bg-blue-700 shadow-lg">
                        <Edit className="w-5 h-5 ml-2" />
                        تحرير البيانات
                      </Button>
                    </Link>
                  ) : (
                    <Link to={createPageUrl(`SuggestEdit?type=Author&id=${authorId}`)}>
                      <Button variant="outline" size="lg" className="shadow-lg">
                        <Edit className="w-5 h-5 ml-2" />
                        اقترح تعديل
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </div>

            {/* Additional Info Section */}
            <div className="mt-8 sm:mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {totalPages > 0 && (
                <div className="p-4 rounded-lg border" style={{background: '#e9e5cd', borderColor: '#d4c4a0'}}>
                  <p className="text-sm text-gray-700 font-medium mb-1">إجمالي الصفحات</p>
                  <p className="text-2xl font-bold" style={{color: '#75420e'}}>{totalPages}</p>
                </div>
              )}
              {featuredBooks > 0 && (
                <div className="p-4 rounded-lg border bg-yellow-50 border-yellow-200">
                  <p className="text-sm text-gray-700 font-medium mb-1">كتب مميزة</p>
                  <p className="text-2xl font-bold text-yellow-600">{featuredBooks}</p>
                </div>
              )}
              {author.birth_year && (
                <div className="p-4 rounded-lg border bg-blue-50 border-blue-200">
                  <p className="text-sm text-gray-700 font-medium mb-1">سنوات النشاط</p>
                  <p className="text-2xl font-bold text-blue-600">{new Date().getFullYear() - author.birth_year}+ سنة</p>
                </div>
              )}
            </div>

            {/* Bio Section */}
            {author.bio && (
              <div className="mt-8 sm:mt-10">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-6 h-6" style={{color: '#75420e'}} />
                  نبذة عن المؤلف
                </h2>
                <p className="text-base sm:text-lg text-gray-700 leading-relaxed p-6 sm:p-8 rounded-xl border-r-4" style={{background: 'linear-gradient(to bottom right, #f5f5f5, #e9e5cd)', borderColor: '#75420e'}}>
                  {author.bio}
                </p>
              </div>
            )}

            <AISummarySection
              entity={authorWithSummary}
              entityType="author"
              isAdmin={user?.role === 'admin'}
              onSummaryGenerated={(s) => setAuthorAiSummary(s)}
            />

            {/* Education & Awards */}
            <div className="mt-8 sm:mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
              {author.education && (
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                      <BookOpen className="w-5 h-5 text-blue-600" />
                      المؤهلات العلمية
                    </h3>
                    <p className="text-gray-700">{author.education}</p>
                  </CardContent>
                </Card>
              )}
              {author.awards && author.awards.length > 0 && (
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                      <Star className="w-5 h-5 text-yellow-500" />
                      الجوائز والتكريمات
                    </h3>
                    <ul className="space-y-2">
                      {author.awards.map((award, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-gray-700">
                          <span className="text-yellow-500 mt-1">•</span>
                          <span>{award}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Contact Information */}
            {(author.email || author.phone || author.social_media) && (
              <div className="mt-8 sm:mt-10">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">معلومات الاتصال</h2>
                <Card>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {author.email && (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <span className="text-lg">📧</span>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-1">البريد الإلكتروني</p>
                            <a href={`mailto:${author.email}`} className="text-blue-600 hover:underline font-medium">
                              {author.email}
                            </a>
                          </div>
                        </div>
                      )}
                      {author.phone && (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">
                          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                            <span className="text-lg">📱</span>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-1">رقم الهاتف</p>
                            <a href={`tel:${author.phone}`} className="text-green-600 hover:underline font-medium">
                              {author.phone}
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                    {author.social_media && (
                      <div className="mt-4 pt-4 border-t">
                        <p className="text-sm text-gray-600 mb-3 font-medium">حسابات التواصل الاجتماعي</p>
                        <div className="flex flex-wrap gap-3">
                          {author.social_media.website && (
                            <a 
                              href={author.social_media.website} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
                            >
                              <Globe className="w-4 h-4" />
                              <span className="text-sm font-medium">الموقع</span>
                            </a>
                          )}
                          {author.social_media.twitter && (
                            <a 
                              href={author.social_media.twitter} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
                            >
                              <span className="text-lg">𝕏</span>
                              <span className="text-sm font-medium">تويتر</span>
                            </a>
                          )}
                          {author.social_media.facebook && (
                            <a 
                              href={author.social_media.facebook} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
                            >
                              <span className="text-lg">📘</span>
                              <span className="text-sm font-medium">فيسبوك</span>
                            </a>
                          )}
                          {author.social_media.instagram && (
                            <a 
                              href={author.social_media.instagram} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-pink-50 hover:bg-pink-100 transition-colors"
                            >
                              <span className="text-lg">📷</span>
                              <span className="text-sm font-medium">انستغرام</span>
                            </a>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Author Bibliography */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3">
              <BookOpen className="w-7 h-7" style={{color: '#75420e'}} />
              قائمة مؤلفات {author.name}
            </h2>
            <div className="px-4 py-2 rounded-full font-bold" style={{background: '#e9e5cd', color: '#75420e'}}>
              {authorBooks.length} كتاب
            </div>
          </div>

          {authorBooks.length === 0 ? (
            <Card className="text-center py-16 sm:py-20 bg-white/50">
              <CardContent>
                <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">لا توجد كتب لهذا المؤلف حالياً</p>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Grid view */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-6 mb-8">
                {authorBooks.map((book) => (
                  <Link key={book.id} to={createPageUrl(`BookDetail?id=${book.id}`)}>
                    <Card className="hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer h-full group">
                      <CardContent className="p-0">
                        <div className="relative overflow-hidden rounded-t-lg">
                          <img
                            src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                            alt={book.title}
                            className="w-full aspect-[2/3] object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                          {book.average_rating > 0 && (
                            <div className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 rounded-lg flex items-center gap-1 shadow-lg">
                              <span className="text-xs font-bold">★ {book.average_rating?.toFixed(1)}</span>
                            </div>
                          )}
                          {book.language && (
                            <div className="absolute top-2 right-2 bg-black/60 text-white px-1.5 py-0.5 rounded text-xs">
                              {book.language}
                            </div>
                          )}
                        </div>
                        <div className="p-3 sm:p-4">
                          <h3 className="font-bold text-sm sm:text-base text-gray-900 mb-1 line-clamp-2 group-hover:text-orange-600 transition-colors">
                            {book.title}
                          </h3>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {(book.published_year || book.publication_year) && (
                              <p className="text-xs text-gray-500 flex items-center gap-0.5">
                                <Calendar className="w-3 h-3" />
                                {book.published_year || book.publication_year}
                              </p>
                            )}
                            {book.pages && (
                              <p className="text-xs text-gray-400">· {book.pages} ص</p>
                            )}
                          </div>
                          {book.genres?.length > 0 && (
                            <span className="inline-block mt-1.5 text-xs px-2 py-0.5 rounded-full" style={{background: '#e9e5cd', color: '#75420e'}}>
                              {book.genres[0]}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>

              {/* List/Bibliography view */}
              <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-4 border-b pb-2">الببليوغرافيا الكاملة</h3>
                <div className="space-y-2">
                  {[...authorBooks]
                    .sort((a, b) => (b.published_year || b.publication_year || 0) - (a.published_year || a.publication_year || 0))
                    .map((book, idx) => (
                    <Link key={book.id} to={createPageUrl(`BookDetail?id=${book.id}`)}>
                      <div className="flex items-center gap-4 p-4 rounded-xl bg-white hover:bg-orange-50 transition-colors border border-gray-100 hover:border-orange-200 group">
                        <span className="text-gray-400 text-sm font-mono w-6 text-center flex-shrink-0">{idx + 1}</span>
                        <img
                          src={book.cover_image || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/697e4ed41f92b5fbb1277c43/44911561c_IMG_7124.png'}
                          alt={book.title}
                          className="w-10 h-14 object-cover rounded shadow flex-shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-900 group-hover:text-orange-700 transition-colors truncate">{book.title}</p>
                          <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-0.5">
                            {(book.published_year || book.publication_year) && (
                              <span className="text-xs text-gray-500">{book.published_year || book.publication_year}</span>
                            )}
                            {book.pages && <span className="text-xs text-gray-400">{book.pages} صفحة</span>}
                            {book.language && <span className="text-xs text-gray-400">{book.language}</span>}
                            {book.isbn && <span className="text-xs text-gray-400">ISBN: {book.isbn}</span>}
                          </div>
                        </div>
                        {book.average_rating > 0 && (
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm font-medium text-gray-700">{book.average_rating?.toFixed(1)}</span>
                          </div>
                        )}
                        {book.genres?.length > 0 && (
                          <span className="hidden sm:inline text-xs px-2 py-1 rounded-full flex-shrink-0" style={{background: '#e9e5cd', color: '#75420e'}}>
                            {book.genres[0]}
                          </span>
                        )}
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}